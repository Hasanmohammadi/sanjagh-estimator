module type Icon = {
  @react.component
  let make: (
    ~size: string=?,
    ~color: string=?,
    ~title: string=?,
    ~className: string=?,
    ~children: React.element=?,
  ) => React.element
}

module NoIcon = {
  @react.component
  let make = (
    ~size: option<string>=?,
    ~color: option<string>=?,
    ~title: option<string>=?,
    ~className: option<string>=?,
    ~children: option<React.element>=?,
  ) => {
    let _ = size
    let _ = color
    let _ = title
    let _ = className
    let _ = children

    React.null
  }
}

module Fa = {
  module FaIdCard = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaIdCard"
  }

  module FaLinkedinIn = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaLinkedinIn"
  }

  module FaInstagram = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaInstagram"
  }

  module FaTelegramPlane = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaTelegramPlane"
  }

  module FaBars = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaBars"
  }

  module FaTwitter = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaTwitter"
  }

  module FaPaperPlane = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaPaperPlane"
  }

  module FaStar = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaStar"
  }

  module FaCheck = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaCheck"
  }

  module FaGlobe = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaGlobe"
  }

  module FaUser = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaUser"
  }

  module FaAward = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAward"
  }

  module FaMapMarkerAlt = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaMapMarkerAlt"
  }

  module FaEllipsisH = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaEllipsisH"
  }

  module FaTimes = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaTimes"
  }

  module FaAngleRight = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleRight"
  }

  module FaAngleDown = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleDown"
  }

  module FaAngleLeft = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleLeft"
  }

  module FaAngleUp = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleUp"
  }

  module FaMap = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaMap"
  }

  module FaPlus = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaPlus"
  }

  module FaChartLine = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaChartLine"
  }

  module FaSearch = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaSearch"
  }

  module FaAddressCard = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAddressCard"
  }

  module FaMobileAlt = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaMobileAlt"
  }

  module FaQuestion = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaQuestion"
  }

  module FaApple = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaApple"
  }
  module FaPhone = {
    @module("react-icons/fa") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaPhone"
  }
}

module Hi = {
  module HiBadgeCheck = {
    @module("react-icons/hi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiBadgeCheck"
  }

  module HiLocationMarker = {
    @module("react-icons/hi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiLocationMarker"
  }

  module HiOutlineLocationMarker = {
    @module("react-icons/hi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlineLocationMarker"
  }

  module HiOutlineClock = {
    @module("react-icons/hi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlineClock"
  }

  module HiOutlinePencil = {
    @module("react-icons/hi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlinePencil"
  }

  module HiDotsHorizontal = {
    @module("react-icons/hi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiDotsHorizontal"
  }

  module HiOutlineDevicePhoneMobile = {
    @module("react-icons/hi2") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlineDevicePhoneMobile"
  }
}

module Fi = {
  module FiSearch = {
    @module("react-icons/fi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FiSearch"
  }
  
  module FiYoutube = {
    @module("react-icons/fi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FiYoutube"
  }
}

module Go = {
  module GoCheck = {
    @module("react-icons/go") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "GoCheck"
  }
}

module Cg = {
  module CgClose = {
    @module("react-icons/cg") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "CgClose"
  }
}

module Md = {
  module MyLocation = {
    @module("react-icons/md") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "MdMyLocation"
  }

  module MdOutlineErrorOutline = {
    @module("react-icons/md") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "MdOutlineErrorOutline"
  }

  module MdVerified = {
    @module("react-icons/md") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "MdVerified"
  }
}

module Io = {
  module IoIosCloseCircle = {
    @module("react-icons/io") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosCloseCircle"
  }


  module IoIosArrowUp = {
    @module("react-icons/io") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowUp"
  }

  module IoIosArrowDown = {
    @module("react-icons/io") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowDown"
  }

  module IoIosArrowForward = {
    @module("react-icons/io") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowForward"
  }

  module IoIosArrowBack = {
    @module("react-icons/io") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowBack"
  }
}

module Bs = {
  module BsThreeDots = {
    @module("react-icons/bs") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsThreeDots"
  }
  module BsTelephone = {
    @module("react-icons/bs") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsTelephone"
  }
  module BsInstagram = {
    @module("react-icons/bs") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsInstagram"
  }
  module BsChatSquareText = {
    @module("react-icons/bs") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsChatSquareTextFill"
  }
}

module Io5 = {
  module ChatBubble = {
    @module("react-icons/io5") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoChatbubble"
  }

  module Call = {
    @module("react-icons/io5") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoCall"
  }
}

module Bi = {
  module BiWorld = {
    @module("react-icons/bi") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BiWorld"
  }
}



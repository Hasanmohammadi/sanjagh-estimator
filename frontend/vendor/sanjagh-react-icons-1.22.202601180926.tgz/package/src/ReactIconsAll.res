module type Icon = {
  @react.component
  let make: (
    ~size: string=?,
    ~color: string=?,
    ~title: string=?,
    ~className: string=?,
    ~children: React.element=?,
  ) => React.element
}

module NoIcon = {
  @react.component
  let make = (
    ~size: option<string>=?,
    ~color: option<string>=?,
    ~title: option<string>=?,
    ~className: option<string>=?,
    ~children: option<React.element>=?,
  ) => {
    let _ = size
    let _ = color
    let _ = title
    let _ = className
    let _ = children

    React.null
  }
}

module Fa = {
  module FaIdCard = {
    @module("@react-icons/all-files/fa/FaIdCard") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaIdCard"
  }

  module FaLinkedinIn = {
    @module("@react-icons/all-files/fa/FaLinkedinIn") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaLinkedinIn"
  }

  module FaInstagram = {
    @module("@react-icons/all-files/fa/FaInstagram") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaInstagram"
  }

  module FaTelegramPlane = {
    @module("@react-icons/all-files/fa/FaTelegramPlane") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaTelegramPlane"
  }

  module FaBars = {
    @module("@react-icons/all-files/fa/FaBars") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaBars"
  }

  module FaTwitter = {
    @module("@react-icons/all-files/fa/FaTwitter") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaTwitter"
  }

  module FaPaperPlane = {
    @module("@react-icons/all-files/fa/FaPaperPlane") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaPaperPlane"
  }

  module FaStar = {
    @module("@react-icons/all-files/fa/FaStar") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaStar"
  }

  module FaCheck = {
    @module("@react-icons/all-files/fa/FaCheck") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaCheck"
  }

  module FaGlobe = {
    @module("@react-icons/all-files/fa/FaGlobe") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaGlobe"
  }

  module FaUser = {
    @module("@react-icons/all-files/fa/FaUser") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaUser"
  }

  module FaAward = {
    @module("@react-icons/all-files/fa/FaAward") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAward"
  }

  module FaMapMarkerAlt = {
    @module("@react-icons/all-files/fa/FaMapMarkerAlt") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaMapMarkerAlt"
  }

  module FaEllipsisH = {
    @module("@react-icons/all-files/fa/FaEllipsisH") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaEllipsisH"
  }

  module FaTimes = {
    @module("@react-icons/all-files/fa/FaTimes") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaTimes"
  }

  module FaAngleRight = {
    @module("@react-icons/all-files/fa/FaAngleRight") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleRight"
  }

  module FaAngleDown = {
    @module("@react-icons/all-files/fa/FaAngleDown") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleDown"
  }

  module FaAngleLeft = {
    @module("@react-icons/all-files/fa/FaAngleLeft") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleLeft"
  }

  module FaAngleUp = {
    @module("@react-icons/all-files/fa/FaAngleUp") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAngleUp"
  }

  module FaMap = {
    @module("@react-icons/all-files/fa/FaMap") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaMap"
  }

  module FaPlus = {
    @module("@react-icons/all-files/fa/FaPlus") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaPlus"
  }

  module FaChartLine = {
    @module("@react-icons/all-files/fa/FaChartLine") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaChartLine"
  }

  module FaSearch = {
    @module("@react-icons/all-files/fa/FaSearch") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaSearch"
  }

  module FaAddressCard = {
    @module("@react-icons/all-files/fa/FaAddressCard") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaAddressCard"
  }

  module FaMobileAlt = {
    @module("@react-icons/all-files/fa/FaMobileAlt") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaMobileAlt"
  }

  module FaQuestion = {
    @module("@react-icons/all-files/fa/FaQuestion") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaQuestion"
  }

  module FaApple = {
    @module("@react-icons/all-files/fa/FaApple") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaApple"
  }
  module FaPhone = {
    @module("@react-icons/all-files/fa/FaPhone") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FaPhone"
  }
}

module Hi = {
  module HiBadgeCheck = {
    @module("@react-icons/all-files/hi/HiBadgeCheck") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiBadgeCheck"
  }

  module HiLocationMarker = {
    @module("@react-icons/all-files/hi/HiLocationMarker") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiLocationMarker"
  }

  module HiOutlineLocationMarker = {
    @module("@react-icons/all-files/hi/HiOutlineLocationMarker") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlineLocationMarker"
  }

  module HiOutlineClock = {
    @module("@react-icons/all-files/hi/HiOutlineClock") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlineClock"
  }

  module HiOutlinePencil = {
    @module("@react-icons/all-files/hi/HiOutlinePencil") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlinePencil"
  }

  module HiDotsHorizontal = {
    @module("@react-icons/all-files/hi/HiDotsHorizontal") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiDotsHorizontal"
  }

  module HiOutlineDevicePhoneMobile = {
    @module("@react-icons/all-files/hi2/HiOutlineDevicePhoneMobile") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "HiOutlineDevicePhoneMobile"
  }
}

module Fi = {
  module FiSearch = {
    @module("@react-icons/all-files/fi/FiSearch") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "FiSearch"
  }
}

module Go = {
  module GoCheck = {
    @module("@react-icons/all-files/go/GoCheck") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "GoCheck"
  }
}

module Cg = {
  module CgClose = {
    @module("@react-icons/all-files/cg/CgClose") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "CgClose"
  }
}

module Md = {
  module MyLocation = {
    @module("@react-icons/all-files/md/MdMyLocation") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "MdMyLocation"
  }

  module MdOutlineErrorOutline = {
    @module("@react-icons/all-files/md/MdOutlineErrorOutline") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "MdOutlineErrorOutline"
  }

  module MdVerified = {
    @module("@react-icons/all-files/md/MdVerified") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "MdVerified"
  }
}

module Io = {
  module IoIosCloseCircle = {
    @module("@react-icons/all-files/io/IoIosCloseCircle") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosCloseCircle"
  }

  module IoIosArrowUp = {
    @module("@react-icons/all-files/io/IoIosArrowUp") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowUp"
  }

  module IoIosArrowDown = {
    @module("@react-icons/all-files/io/IoIosArrowDown") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowDown"
  }

  module IoIosArrowForward = {
    @module("@react-icons/all-files/io/IoIosArrowForward") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowForward"
  }

  module IoIosArrowBack = {
    @module("@react-icons/all-files/io/IoIosArrowBack") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoIosArrowBack"
  }
}

module Bs = {
  module BsThreeDots = {
    @module("@react-icons/all-files/bs/BsThreeDots") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsThreeDots"
  }
  module BsTelephone = {
    @module("@react-icons/all-files/bs/BsTelephone") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsTelephone"
  }
  module BsInstagram = {
    @module("@react-icons/all-files/bs/BsInstagram") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsInstagram"
  }
  module BsChatSquareText = {
    @module("@react-icons/all-files/bs/BsChatSquareFill") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BsChatSquareFill"
  }
}

module Io5 = {
  module ChatBubble = {
    @module("@react-icons/all-files/io5/IoChatbubble") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoChatbubble"
  }

  module Call = {
    @module("@react-icons/all-files/io5/IoCall") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "IoCall"
  }
}

module Bi = {
  module BiWorld = {
    @module("@react-icons/all-files/bi/BiWorld") @react.component
    external make: (
      ~size: string=?,
      ~color: string=?,
      ~title: string=?,
      ~className: string=?,
      ~children: React.element=?,
    ) => React.element = "BiWorld"
  }
}

import { GoCheck } from 'react-icons/go';

type CheckBoxSize = 'SmallCheckBox' | 'MediumCheckBox' | 'LargeCheckBox';

export type Design_CheckBoxProps = {
  size: CheckBoxSize;
  label: string;
  isChecked: boolean;
  onClick: (nextChecked: boolean) => void;
  disabled?: boolean;
  hasError?: boolean;
};

function sizeClasses(size: CheckBoxSize): { box: string; font: string } {
  switch (size) {
    case 'SmallCheckBox':
      return {
        box: 'w-4 h-4 min-w-[16px] min-h-[16px]',
        font: 'text-xs',
      };
    case 'MediumCheckBox':
      return {
        box: 'w-[18px] h-[18px] min-w-[18px] min-h-[18px]',
        font: 'text-sm',
      };
    case 'LargeCheckBox':
      return {
        box: 'w-5 h-5 min-w-[20px] min-h-[20px]',
        font: 'text-base',
      };
  }
}

function iconSize(size: CheckBoxSize): string {
  switch (size) {
    case 'SmallCheckBox':
      return '0.75em';
    case 'MediumCheckBox':
      return '0.9em';
    case 'LargeCheckBox':
      return '1em';
  }
}

/** Local TS port of design-system `Design_CheckBox` (package is `.res` only). */
export default function Design_CheckBox({
  size,
  label,
  isChecked,
  onClick,
  disabled = false,
  hasError = false,
}: Design_CheckBoxProps) {
  const { box, font } = sizeClasses(size);
  const base =
    'ml-2 rounded-[4px] border border-solid border-grayDesign-300 flex justify-center items-center overflow-visible';
  const checkedBg = hasError
    ? 'bg-newRedDesign-main'
    : 'bg-blackDesign-main';
  const boxClassName = isChecked
    ? `${base} ${box} border-none ${checkedBg}`
    : `${base} ${box}`;

  return (
    <span
      className="flex cursor-pointer items-center"
      onClick={() => {
        if (!disabled) {
          onClick(!isChecked);
        }
      }}
    >
      <span className={boxClassName}>
        {isChecked ? (
          <GoCheck size={iconSize(size)} className="text-white stroke-[2px]" />
        ) : null}
      </span>
      <span
        className={`${font}${disabled ? 'text-grayDesign-300' : ''} pt-[2px]`}
      >
        {label}
      </span>
    </span>
  );
}

module ReactRating = Design_ReactRating_bindings

type size = Small | Large | XLarge

module StarRating = {
  @react.component
  let make = (~full: bool, ~size, ~color) => {
    let colorClassName = switch color {
    | Some(c) => c
    | None => "text-black"
    }
    let baseClassName = full ? colorClassName : "text-grayDesign-200"
    let sizeClassName = switch size {
    | Small => "text-sm"
    | Large => "text-2xl"
    | XLarge => "text-3xl"
    }
    let className = `${baseClassName} ${sizeClassName}`

    <div className>
      <ReactIcons.Fa.FaStar />
    </div>
  }
}

module StaticRatingStars = {
  @react.component
  let make = (~size, ~rate, ~onRateChange: option<int => unit>=?, ~color: option<string>=?) => {
    let onChange = (rate: int) => {
      switch onRateChange {
      | Some(func) => func(rate)
      | None => ()
      }
    }
    <ReactRating
      emptySymbol={<StarRating size full=false color />}
      fullSymbol={<StarRating size full=true color />}
      readonly={onRateChange->Option.isSome ? false : true}
      direction="ltr"
      initialRating={rate}
      onChange
    />
  }
}

module NumericRatingStars = {
  @react.component
  let make = (~size, ~rate, ~color: option<string>=?) => {
    let roundedRate = Js.Math.round(rate *. 10.) /. 10.
    let textColor = switch color {
    | Some(c) => c
    | None => ""
    }

    <div className="flex">
      <span className={`font-bold ml-1 ${textColor}`}> {roundedRate->React.float} </span>
      <div className="mt-[2px]">
        <StarRating size full={true} color />
      </div>
    </div>
  }
}

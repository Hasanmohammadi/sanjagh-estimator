open Design_CommonTypes

type widthVariant = AutoWidthButton | FixedWidthButton
type heightVariant = XSButton | SMButton | MDButton | LGButton | XLGButton | XXLGButton
type buttonVariant =
  | PrimarySolidButton
  | SecondaryOutlineButton
  | SecondaryGrayButton
  | TertiaryMainButton
  | LinkMainButton

type iconButtonVariant =
  | PrimarySolidIconButton
  | SecondaryOutlineIconButton
  | SecondaryGrayIconButton
  | TertiaryMainIconButton

type iconButtonSize = SmallIconButton | LargeIconButton

%%private(
  let rippleEffect = "relative overflow-hidden after:content-[''] after:bg-[rgba(0,0,0,0.08)] after:rounded-full after:block after:absolute after:top-0 after:right-0 after:bottom-0 after:left-0 after:scale-x-[0.001] after:scale-y-[0.001] after:opacity-0 after:transition-all after:duration-700 after:ease-out active:after:scale-x-[1.2] active:after:scale-y-[1.2] active:after:opacity-100 active:after:duration-0"
)

module Button = {
  @react.component
  let make = (
    ~contentVariant,
    ~onClick: option<ReactEvent.Mouse.t => unit>=?,
    ~widthVariant,
    ~heightVariant,
    ~buttonVariant,
    ~disabled=false,
    ~extraClassName="",
    ~containError=false,
  ) => {
    let buttonHorizontalSizing = switch widthVariant {
    | AutoWidthButton => {
        let className = "w-fit"
        className
      }
    | FixedWidthButton => {
        let className = "w-full"
        className
      }
    }

    let buttonVerticalSizing = switch heightVariant {
    | XSButton => {
        let className = "text-xs font-bold px-3 h-6 rounded-[4px]"
        className
      }
    | SMButton => {
        let className = "text-sm font-bold px-4 h-8 rounded-lg"
        className
      }
    | MDButton => {
        let className = "text-sm font-bold px-5 h-10 rounded-lg"
        className
      }
    | LGButton => {
        let className = "text-base font-bold px-7 h-12 rounded-lg"
        className
      }
    | XLGButton => {
        let className = "text-lg font-bold px-8 h-14 rounded-xl"
        className
      }
    | XXLGButton => {
        let className = "text-2xl font-bold h-[72px] rounded-xl"
        className
      }
    }

    let buttonVariantBasedClassName = switch buttonVariant {
    | PrimarySolidButton => {
        let className = "bg-black text-white outline-none border-none hover:bg-blackDesign-main disabled:bg-grayDesign-200"
        className
      }

    | SecondaryOutlineButton => {
        let baseClassName = "bg-white text-black border-black border-solid disabled:border-grayDesign-200 disabled:text-grayDesign-200 hover:bg-grayDesign-50 disabled:hover:bg-transparent"
        let borderClassName = heightVariant === XSButton ? "border" : "border-2"
        baseClassName ++ " " ++ borderClassName
      }
    | SecondaryGrayButton => {
        let baseClassName = "bg-white text-black border-grayDesign-200 border-solid hover:bg-grayDesign-100  disabled:text-grayDesign-200 disabled:hover:bg-transparent"
        let borderClassName = heightVariant === XSButton ? "border" : "border-2"
        baseClassName ++ " " ++ borderClassName
      }
    | TertiaryMainButton => {
        let className = "bg-grayDesign-100 text-black border-none outline-none hover:bg-grayDesign-200 disabled:bg-grayDesign-50 disabled:text-grayDesign-200"
        className
      }
    | LinkMainButton => {
        let className = "bg-transparent border-none outline-none text-blueDesign-main hover:text-blueDesign-dark disabled:text-grayDesign-200"
        className
      }
    }

    let errorClassName = switch buttonVariant {
    | PrimarySolidButton => "bg-newRedDesign-light hover:bg-newRedDesign-main"
    | SecondaryOutlineButton => "text-newRedDesign-light border-newRedDesign-light hover:bg-[#FDDCDC]"
    | SecondaryGrayButton => "text-newRedDesign-light"
    | TertiaryMainButton => "text-newRedDesign-light bg-[#FDDCDC] hover:bg-[#FFD4D4]"
    | LinkMainButton => "text-newRedDesign-light hover:text-newRedDesign-main"
    }

    let buttonClassName = `${buttonHorizontalSizing} ${buttonVerticalSizing} ${buttonVariantBasedClassName} ${extraClassName} ${rippleEffect} ${containError
        ? errorClassName
        : ""}`

    let content = switch contentVariant {
    | Text(txt) => React.string(txt)
    | TextWithIcon({text, icon, iconPosition}) => {
        let module(ButtonIcon) = icon
        let className =
          iconPosition === RightPositionedIcon
            ? "flex flex-row-reverse justify-center items-center"
            : "flex flex-row justify-center items-center"
        let iconMarginClassName = iconPosition === RightPositionedIcon ? "ml-2" : "mr-2"
        <div className>
          <span> {React.string(text)} </span>
          <ButtonIcon className={`${iconMarginClassName}`} />
        </div>
      }
    }

    switch onClick {
    | Some(fn) => <button onClick={fn} disabled className={buttonClassName}> {content} </button>

    | None => <button disabled className={buttonClassName}> {content} </button>
    }
  }
}

module IconButton = {
  @react.component
  let make = (~variant, ~icon: icon, ~size, ~containError=false, ~disabled=false, ~onClick) => {
    let buttonBaseCalssName = {
      let className = "flex justify-center items-center"
      className
    }

    let (buttonSizeClassName, iconSizeClassName) = switch size {
    | SmallIconButton => {
        let button = {
          let className = "w-10 h-10 rounded-lg"
          className
        }

        let icon = {
          let className = "text-base"
          className
        }

        (button, icon)
      }
    | LargeIconButton => {
        let button = {
          let className = "w-12 h-12 rounded-lg"
          className
        }

        let icon = {
          let className = "text-lg"
          className
        }

        (button, icon)
      }
    }

    let buttonVariantBasedClassName = switch variant {
    | PrimarySolidIconButton => {
        let className = "bg-black text-white outline-none border-none hover:bg-blackDesign disabled:bg-grayDesign-200"
        className
      }
    | SecondaryOutlineIconButton => {
        let className = "bg-white text-black border-black border-2 border-solid disabled:border-grayDesign-200 disabled:text-grayDesign-200 hover:bg-grayDesign-50 disabled:hover:bg-transparent"
        className
      }
    | SecondaryGrayIconButton => {
        let className = "bg-white text-black border-grayDesign-200 border-2 hover:bg-grayDesign-100 disabled:border-grayDesign-200 disabled:text-grayDesign-200 disabled:hover:bg-transparent"
        className
      }
    | TertiaryMainIconButton => {
        let className = "bg-grayDesign-100 text-black border-none outline-none hover:bg-grayDesign-200 disabled:bg-grayDesign-50 disabled:text-grayDesign-200"
        className
      }
    }

    let errorClassName = switch variant {
    | PrimarySolidIconButton => "bg-newRedDesign-light hover:bg-newRedDesign-main"
    | SecondaryOutlineIconButton => "text-newRedDesign-light border-newRedDesign-light hover:!bg-[#FDDCDC]"
    | SecondaryGrayIconButton => "text-newRedDesign-light"
    | TertiaryMainIconButton => "text-newRedDesign-light !bg-[#FDDCDC] hover:!bg-[#FFD4D4]"
    }

    let buttonClassName = `${buttonBaseCalssName} ${buttonSizeClassName} ${buttonVariantBasedClassName} ${rippleEffect} ${containError
        ? errorClassName
        : ""}`

    let iconApplicableClassName = `${iconSizeClassName}`

    let module(Icon) = icon

    <button className={buttonClassName} onClick disabled>
      <Icon className={iconApplicableClassName} />
    </button>
  }
}

type checkBoxSize = SmallCheckBox | MediumCheckBox | LargeCheckBox

@react.component
let make = (~size, ~label, ~onClick, ~isChecked, ~disabled=false, ~hasError=false) => {
  let baseClassName = "ml-2 rounded-[4px] border border-solid border-grayDesign-300 flex justify-center items-center overflow-visible"

  let (sizeClassName, fontSizeClassName) = switch size {
  | SmallCheckBox => {
      let sizeClassName = {
        let className = "w-4 h-4 min-w-[16px] min-h-[16px]"
        className
      }

      let fontSizeClassName = {
        let className = "text-xs"
        className
      }

      (sizeClassName, fontSizeClassName)
    }
  | MediumCheckBox => {
      let sizeClassName = {
        let className = "w-[18px] h-[18px] min-w-[18px] min-h-[18px]"
        className
      }

      let fontSizeClassName = {
        let className = "text-sm"
        className
      }

      (sizeClassName, fontSizeClassName)
    }
  | LargeCheckBox => {
      let sizeClassName = {
        let className = "w-5 h-5 min-w-[20px] min-h-[20px]"
        className
      }

      let fontSizeClassName = {
        let className = "text-base"
        className
      }

      (sizeClassName, fontSizeClassName)
    }
  }

  let iconSize = switch size {
  | SmallCheckBox => "0.75em"
  | MediumCheckBox => "0.9em"
  | LargeCheckBox => "1em"
  }

  let checkedClassName = {
    let className = `border-none ${hasError ? "bg-newRedDesign-main" : "bg-blackDesign-main "}`
    `${baseClassName} ${sizeClassName} ${className}`
  }

  let uncheckedClassName = `${baseClassName} ${sizeClassName}`

  let handleClick = _ => {
    switch disabled {
    | true => ()
    | false =>
      let newIsChecked = !isChecked
      onClick(newIsChecked)
    }
  }

  <span className="flex cursor-pointer items-center" onClick={handleClick}>
    <span className={isChecked ? checkedClassName : uncheckedClassName}>
      {isChecked
        ? <ReactIcons.Go.GoCheck size={iconSize} className="text-white stroke-[2px]" />
        : React.null}
    </span>
    <span className={fontSizeClassName ++ `${disabled ? "text-grayDesign-300" : ""} pt-[2px]`}>
      {React.string(label)}
    </span>
  </span>
}

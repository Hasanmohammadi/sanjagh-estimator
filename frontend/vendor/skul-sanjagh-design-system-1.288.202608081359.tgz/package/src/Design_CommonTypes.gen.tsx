/* TypeScript file generated from Design_CommonTypes.res by genType. */
/* eslint-disable import/first */


// tslint:disable-next-line:interface-over-type-literal
export type iconPosition = 
    "RightPositionedIcon"
  | "LeftPositionedIcon";

// tslint:disable-next-line:interface-over-type-literal
export type icon = unknown;

// tslint:disable-next-line:interface-over-type-literal
export type contentVariant = 
    { tag: "Text"; value: string }
  | { tag: "TextWithIcon"; value: {
  readonly text: string; 
  readonly icon: icon; 
  readonly iconPosition: iconPosition
} };

// tslint:disable-next-line:interface-over-type-literal
export type shadowVariant = "NoShadow" | "Low" | "High";

// tslint:disable-next-line:interface-over-type-literal
export type colorVariant = 
    "PurpleDark"
  | "PurpleLight"
  | "PurpleMain"
  | "PurpleVeryLight"
  | "BlackMain"
  | "BlueMain"
  | "Gray50"
  | "Gray100"
  | "Gray150"
  | "Gray200"
  | "Gray300"
  | "Gray400"
  | "Gray500"
  | "Gray600"
  | "GreenMain"
  | "NewGreenMain"
  | "RedMain"
  | "NewRedMain"
  | "YellowMain";

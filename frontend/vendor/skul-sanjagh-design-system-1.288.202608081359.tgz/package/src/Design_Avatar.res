@module("/public/images/icons/waiting-pro-avatar.svg")
external unknownAvatar: string = "default"

module IsVerifiedIcon = {
  @react.component
  let make = () => {
    <svg
      className="absolute right-0 bottom-0"
      width="22"
      height="22"
      viewBox="0 0 22 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M9.74172 1.4425C10.4315 0.8525 11.561 0.8525 12.2608 1.4425L13.8402 2.80261C14.1401 3.06261 14.6998 3.27258 15.0997 3.27258H16.7991C17.8587 3.27258 18.7283 4.14251 18.7283 5.20251V6.90258C18.7283 7.29258 18.9383 7.86259 19.1982 8.16259L20.5577 9.74255C21.1474 10.4326 21.1474 11.5626 20.5577 12.2626L19.1982 13.8425C18.9383 14.1425 18.7283 14.7025 18.7283 15.1025V16.8026C18.7283 17.8626 17.8587 18.7325 16.7991 18.7325H15.0997C14.7098 18.7325 14.1401 18.9425 13.8402 19.2025L12.2608 20.5625C11.571 21.1525 10.4415 21.1525 9.74172 20.5625L8.16232 19.2025C7.86244 18.9425 7.30264 18.7325 6.90279 18.7325H5.17342C4.11382 18.7325 3.24416 17.8626 3.24416 16.8026V15.0925C3.24416 14.7025 3.03424 14.1425 2.78434 13.8425L1.43484 12.2526C0.855054 11.5626 0.855054 10.4426 1.43484 9.75256L2.78434 8.16259C3.03424 7.86259 3.24416 7.30259 3.24416 6.91259V5.20251C3.24416 4.14251 4.11382 3.27258 5.17342 3.27258H6.90279C7.29264 3.27258 7.86244 3.06261 8.16232 2.80261L9.74172 1.4425Z"
        fill="black"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M10.1318 1.89844C10.1315 1.89864 10.132 1.89824 10.1318 1.89844L8.55539 3.25594C8.55511 3.25619 8.55482 3.25644 8.55453 3.25669C8.3336 3.44798 8.04647 3.59672 7.77536 3.69749C7.50397 3.79837 7.191 3.87257 6.90281 3.87257H5.17345C4.44541 3.87257 3.84418 4.47369 3.84418 5.2025V6.91259C3.84418 7.20118 3.76982 7.51169 3.6707 7.77955C3.57128 8.04823 3.42657 8.32909 3.24537 8.54661L3.24183 8.55086L1.89423 10.1385C1.89394 10.1389 1.89365 10.1392 1.89336 10.1396C1.50225 10.6062 1.50225 11.3989 1.89336 11.8655C1.89365 11.8659 1.89394 11.8662 1.89423 11.8666L3.24539 13.4585C3.42659 13.676 3.57128 13.9569 3.6707 14.2256C3.76982 14.4934 3.84418 14.8039 3.84418 15.0925V16.8026C3.84418 17.5314 4.44541 18.1325 5.17345 18.1325H6.90281C7.19519 18.1325 7.50814 18.2063 7.78012 18.308C8.05174 18.4095 8.33519 18.5585 8.55462 18.7485C8.55488 18.7487 8.55514 18.7489 8.55539 18.7492L10.1306 20.1055C10.6085 20.5066 11.4071 20.5025 11.8701 20.1071C11.8699 20.1073 11.8703 20.1069 11.8701 20.1071L13.4472 18.7492C13.4474 18.7489 13.4477 18.7487 13.448 18.7485C13.6689 18.5572 13.956 18.4084 14.2272 18.3076C14.4986 18.2067 14.8115 18.1325 15.0997 18.1325H16.7991C17.5271 18.1325 18.1284 17.5314 18.1284 16.8026V15.1025C18.1284 14.8101 18.2021 14.4971 18.3037 14.2251C18.4051 13.9536 18.5539 13.6703 18.7437 13.4508C18.744 13.4504 18.7444 13.45 18.7447 13.4496L20.1006 11.8739C20.5016 11.3956 20.4976 10.5964 20.1022 10.133C20.102 10.1328 20.1023 10.1333 20.1022 10.133L18.7447 8.55546C18.7444 8.55512 18.7441 8.55478 18.7438 8.55444C18.5527 8.33348 18.4041 8.04636 18.3034 7.77525C18.2025 7.5038 18.1284 7.19078 18.1284 6.90258V5.2025C18.1284 4.47369 17.5271 3.87257 16.7991 3.87257H15.0997C14.8073 3.87257 14.4944 3.79876 14.2224 3.69712C13.9508 3.59561 13.6674 3.44664 13.448 3.25664C13.4477 3.25641 13.4474 3.25617 13.4472 3.25594L11.8719 1.89939C11.3939 1.49844 10.5948 1.50308 10.1318 1.89844ZM9.35173 0.986546C10.2676 0.203108 11.726 0.206764 12.6476 0.983789L12.6523 0.987815L14.2333 2.34926C14.3136 2.41893 14.4597 2.50471 14.6425 2.57306C14.8254 2.6414 14.9922 2.67257 15.0997 2.67257H16.7991C18.1903 2.67257 19.3284 3.81132 19.3284 5.2025V6.90258C19.3284 7.00438 19.3592 7.17136 19.4283 7.35741C19.4973 7.54339 19.5833 7.69081 19.6517 7.76971L19.653 7.77124L21.0138 9.3527C21.7968 10.2688 21.7932 11.7274 21.0165 12.6492L21.0125 12.6539L19.653 14.2339L19.6517 14.2354C19.582 14.3158 19.4962 14.4619 19.4279 14.6449C19.3596 14.8279 19.3284 14.9949 19.3284 15.1025V16.8026C19.3284 18.1938 18.1903 19.3325 16.7991 19.3325H15.0997C14.9981 19.3325 14.8312 19.3633 14.6453 19.4324C14.4594 19.5015 14.3121 19.5875 14.2333 19.6558L14.2317 19.6572L12.6523 21.0172L12.6508 21.0184C11.7349 21.8019 10.2765 21.7982 9.35498 21.0212L9.35022 21.0172L7.77084 19.6572L7.76931 19.6558C7.68895 19.5862 7.54291 19.5004 7.36002 19.432C7.17716 19.3637 7.01029 19.3325 6.90281 19.3325H5.17345C3.78229 19.3325 2.64418 18.1938 2.64418 16.8026V15.0925C2.64418 14.9911 2.61359 14.8266 2.54527 14.642C2.47774 14.4595 2.39327 14.3111 2.32483 14.2283L0.975495 12.6385C0.208197 11.7254 0.208203 10.2797 0.975501 9.36657L0.977415 9.36429L2.32483 7.77679C2.39327 7.69397 2.47774 7.54563 2.54527 7.36312C2.61359 7.17849 2.64418 7.01399 2.64418 6.91259V5.2025C2.64418 3.81132 3.78229 2.67257 5.17345 2.67257H6.90281C7.00448 2.67257 7.17133 2.64179 7.35728 2.57268C7.54314 2.50359 7.69047 2.41762 7.76931 2.34926L7.77082 2.34795L9.35173 0.986546Z"
        fill="white"
      />
      <path
        d="M9.34714 13.1023L9.70437 13.4669L10.0615 13.1022L14.9834 8.07636L14.9835 8.07638L14.9869 8.07279C15.0081 8.05072 15.0344 8.03238 15.0647 8.01959C15.095 8.00678 15.1281 8 15.1619 8C15.1957 8 15.2288 8.00678 15.2591 8.01959C15.2893 8.03238 15.3157 8.05072 15.3369 8.07279L15.338 8.07399C15.3922 8.12999 15.4202 8.20153 15.4202 8.27346C15.4202 8.34501 15.3924 8.41619 15.3389 8.47206C15.3386 8.47235 15.3383 8.47264 15.338 8.47293L9.70424 14.2256L6.58128 11.0377C6.52775 10.9818 6.5 10.9107 6.5 10.8391C6.5 10.7672 6.52806 10.6957 6.58218 10.6397L6.58218 10.6397L6.58333 10.6385C6.60453 10.6164 6.63087 10.598 6.66112 10.5853C6.6914 10.5724 6.72452 10.5657 6.75832 10.5657C6.79212 10.5657 6.82524 10.5724 6.85551 10.5853L7.03453 10.1619L6.85551 10.5853C6.88577 10.598 6.91211 10.6164 6.9333 10.6385L6.93328 10.6385L6.93683 10.6421L9.34714 13.1023Z"
        fill="white"
      />
      <path
        d="M9.34714 13.1023L9.70437 13.4669L10.0615 13.1022L14.9834 8.07636L14.9835 8.07638L14.9869 8.07279C15.0081 8.05072 15.0344 8.03238 15.0647 8.01959C15.095 8.00678 15.1281 8 15.1619 8C15.1957 8 15.2288 8.00678 15.2591 8.01959C15.2893 8.03238 15.3157 8.05072 15.3369 8.07279L15.338 8.07399C15.3922 8.12999 15.4202 8.20153 15.4202 8.27346C15.4202 8.34501 15.3924 8.41619 15.3389 8.47206C15.3386 8.47235 15.3383 8.47264 15.338 8.47293L9.70424 14.2256L6.58128 11.0377C6.52775 10.9818 6.5 10.9107 6.5 10.8391C6.5 10.7672 6.52806 10.6957 6.58218 10.6397L6.58218 10.6397L6.58333 10.6385C6.60453 10.6164 6.63087 10.598 6.66112 10.5853C6.6914 10.5724 6.72452 10.5657 6.75832 10.5657C6.79212 10.5657 6.82524 10.5724 6.85551 10.5853L7.03453 10.1619L6.85551 10.5853C6.88577 10.598 6.91211 10.6164 6.9333 10.6385L6.93328 10.6385L6.93683 10.6421L9.34714 13.1023Z"
        stroke="white"
      />
      <path
        d="M9.34714 13.1023L9.70437 13.4669L10.0615 13.1022L14.9834 8.07636L14.9835 8.07638L14.9869 8.07279C15.0081 8.05072 15.0344 8.03238 15.0647 8.01959C15.095 8.00678 15.1281 8 15.1619 8C15.1957 8 15.2288 8.00678 15.2591 8.01959C15.2893 8.03238 15.3157 8.05072 15.3369 8.07279L15.338 8.07399C15.3922 8.12999 15.4202 8.20153 15.4202 8.27346C15.4202 8.34501 15.3924 8.41619 15.3389 8.47206C15.3386 8.47235 15.3383 8.47264 15.338 8.47293L9.70424 14.2256L6.58128 11.0377C6.52775 10.9818 6.5 10.9107 6.5 10.8391C6.5 10.7672 6.52806 10.6957 6.58218 10.6397L6.58218 10.6397L6.58333 10.6385C6.60453 10.6164 6.63087 10.598 6.66112 10.5853C6.6914 10.5724 6.72452 10.5657 6.75832 10.5657C6.79212 10.5657 6.82524 10.5724 6.85551 10.5853L7.03453 10.1619L6.85551 10.5853C6.88577 10.598 6.91211 10.6164 6.9333 10.6385L6.93328 10.6385L6.93683 10.6421L9.34714 13.1023Z"
        stroke="white"
        strokeOpacity="0.2"
      />
    </svg>
  }
}

type avatar = {src: string}
type avatarSize = Avatar135 | Avatar80 | Avatar56 | Avatar48 | Avatar36
type avatarVariant =
  WaitingForProQuote(option<string>) | KnownAvatar({src: string, alt: string}) | UnknownAvatar
type avatarShape = Rounded | Square(string)
open Design_Next_bindings

module Avatar = {
  @react.component
  let make = (
    ~size,
    ~variant,
    ~isVerified=false,
    ~isTargetedPro=false,
    ~shape=Rounded,
    ~loading: option<[#eager | #"lazy"]>=?,
    ~priority: option<bool>=?,
  ) => {
    let avatarShape = switch shape {
    | Rounded => "rounded-full"
    | Square(v) => v
    }

    let (sizeClassName, imageSize) = switch size {
    | Avatar135 => {
        let className = "w-[135px] h-[135px]"
        (className, 135)
      }
    | Avatar80 => {
        let className = "w-20 h-20"
        (className, 80)
      }
    | Avatar56 => {
        let className = "w-14 h-14"
        (className, 56)
      }
    | Avatar48 => {
        let className = "w-12 h-12"
        (className, 48)
      }
    | Avatar36 => {
        let className = "w-9 h-9"
        (className, 36)
      }
    }

    switch variant {
    | KnownAvatar({src, alt}) =>
      <div className={`relative flex ${sizeClassName}`}>
        <Image
          className={`${avatarShape} ${isTargetedPro ? "grayscale" : ""} object-contain`}
          src
          alt
          width={imageSize}
          height={imageSize}
          unoptimized={true}
          ?loading
          ?priority
        />
        {isVerified ? <IsVerifiedIcon /> : React.null}
      </div>
    | UnknownAvatar =>
      <div className={`relative flex ${sizeClassName}`}>
        <Image
          className={avatarShape}
          src={unknownAvatar}
          alt="unknown image"
          width={imageSize}
          height={imageSize}
          unoptimized={true}
        />
        {isVerified ? <IsVerifiedIcon /> : React.null}
      </div>

    | WaitingForProQuote(maybeProProfilePicSrc) =>
      <div className="relative">
        <div
          className={`absolute top-0 z-10 rounded-full border-[2px] border-transparent bg-transparent border-t-blackDesign-main border-r-blackDesign-main animate-spinSlow ${sizeClassName}`}
        />
        <Image
          className={"rounded-full" ++ (maybeProProfilePicSrc->Option.isSome ? " grayscale" : "")}
          src={maybeProProfilePicSrc->Option.getWithDefault(unknownAvatar)}
          alt="waiting for pro"
          width={imageSize}
          height={imageSize}
          unoptimized={true}
        />
      </div>
    }
  }
}

module AvatarGroup = {
  module WaitingForQuotes = {
    @react.component
    let make = (~waitingCount) => {
      let waitingList = Array.make(waitingCount, Js.Null_undefined.null)

      waitingList
      ->Array.mapWithIndex((index, _) => {
        let zIndex = switch index {
        | 0 => "z-[60]"
        | 1 => "z-50"
        | 2 => "z-40"
        | 3 => "z-30"
        | 4 => "z-20"
        | 5 => "z-10"
        | _ => ""
        }

        <span
          key={zIndex ++ index->Int.toString}
          className={`${zIndex} ${index !== waitingList->Array.length - 1 ? "-ml-2" : ""}`}>
          <Avatar variant={WaitingForProQuote(None)} size={Avatar36} />
        </span>
      })
      ->React.array
    }
  }

  @react.component
  let make = (
    ~avatarList: array<option<string>>,
    ~isWaitingForQuotes,
    ~maybeTargetedProAvatar: option<string>=?,
    ~hasTaskSingleQuote=false,
  ) => {
    let (waitingCount, sortedAvatarList) = switch maybeTargetedProAvatar {
    | Some(targetedPro) => (
        hasTaskSingleQuote ? 0 : 4 - avatarList->Array.length,
        Array.concat([Some(targetedPro)], avatarList),
      )
    | None => (hasTaskSingleQuote ? 0 : 5 - avatarList->Array.length, avatarList)
    }

    <div className="flex justify-end">
      {sortedAvatarList
      ->Array.mapWithIndex((index, src) => {
        let isTargetedPro = maybeTargetedProAvatar->Option.isSome && index === 0

        let variant = switch src {
        | Some(s) =>
          if isTargetedPro {
            WaitingForProQuote(Some(s))
          } else {
            KnownAvatar({src: s, alt: "pro"})
          }
        | None => UnknownAvatar
        }

        let zIndex = switch index {
        | 0 => "z-[110]"
        | 1 => "z-[100]"
        | 2 => "z-[90]"
        | 3 => "z-[80]"
        | 4 => "z-[70]"
        | 5 => "z-[60]"
        | _ => ""
        }

        let className = `${zIndex} ${(index === avatarList->Array.length - 1 &&
            (waitingCount === 0 || !isWaitingForQuotes)) || hasTaskSingleQuote
            ? ""
            : "-ml-2"}`

        let isTargetedPro = maybeTargetedProAvatar->Option.isSome && index === 0

        <span key={zIndex} className>
          <Avatar key={index->Int.toString} size={Avatar36} variant isTargetedPro />
        </span>
      })
      ->React.array}
      {switch isWaitingForQuotes {
      | true => <WaitingForQuotes waitingCount />
      | false => React.null
      }}
    </div>
  }
}

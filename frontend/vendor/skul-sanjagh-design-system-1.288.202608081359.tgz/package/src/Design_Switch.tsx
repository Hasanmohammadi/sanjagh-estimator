import { useCallback, useRef, type ChangeEvent } from 'react';

export type SwitchSize = 'SM' | 'MD' | 'LG';

const SIZE_CONFIG = {
  SM: {
    track: 'w-[26px] h-4',
    thumb: 'w-3 h-3',
    thumbOffset: 'translate-x-3',
    label: 'text-xs',
  },
  MD: {
    track: 'w-[34px] h-5',
    thumb: 'w-4 h-4',
    thumbOffset: 'translate-x-4',
    label: 'text-sm',
  },
  LG: {
    track: 'w-[42px] h-6',
    thumb: 'w-5 h-5',
    thumbOffset: 'translate-x-5',
    label: 'text-base',
  },
} as const satisfies Record<
  SwitchSize,
  {
    track: string;
    thumb: string;
    thumbOffset: string;
    label: string;
  }
>;

export type SwitchProps = {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  label?: string;
  size?: SwitchSize;
  disabled?: boolean;
  id?: string;
  className?: string;
};

/**
 * Local TS port of design-system `Design_Switch.res`.
 * Package `.tsx` uses invalid color tokens (`design-black-1` / `design-gray-300`)
 * that are not in this app's Tailwind theme, so the track renders invisible.
 */
export function Switch({
  checked,
  onCheckedChange,
  label,
  size = 'MD',
  disabled = false,
  id,
  className,
}: SwitchProps) {
  const fallbackIdRef = useRef<string | undefined>(undefined);
  if (fallbackIdRef.current == null) {
    fallbackIdRef.current = `design-switch-${Math.random().toString(36).slice(2, 9)}`;
  }
  const inputId = id ?? fallbackIdRef.current;
  const { track, thumb, thumbOffset, label: labelSizeClass } = SIZE_CONFIG[size];

  const handleChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      onCheckedChange(event.target.checked);
    },
    [onCheckedChange],
  );

  const rootClassName = [
    'inline-flex cursor-pointer select-none items-center gap-3',
    disabled && 'cursor-not-allowed opacity-60',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const labelClassName = [
    labelSizeClass,
    disabled ? 'text-grayDesign-400' : 'text-inherit',
    'pt-[2px]',
  ].join(' ');

  const trackClassName = [
    'block rounded-full transition-colors',
    track,
    checked ? 'bg-blackDesign-main' : 'bg-grayDesign-300',
  ].join(' ');

  const thumbClassName = [
    'absolute top-[2px] left-[1px] flex items-center justify-center rounded-full bg-white transition-transform duration-200',
    thumb,
    checked ? 'translate-x-0' : thumbOffset,
  ].join(' ');

  return (
    <label htmlFor={inputId} className={rootClassName}>
      {label != null && label !== '' ? (
        <span className={labelClassName}>{label}</span>
      ) : null}
      <span className="relative inline-flex shrink-0">
        <input
          id={inputId}
          type="checkbox"
          role="switch"
          className="peer sr-only"
          checked={checked}
          disabled={disabled}
          onChange={handleChange}
          aria-checked={checked}
        />
        <span aria-hidden className={trackClassName} />
        <span aria-hidden className={thumbClassName} />
      </span>
    </label>
  );
}

export default Switch;

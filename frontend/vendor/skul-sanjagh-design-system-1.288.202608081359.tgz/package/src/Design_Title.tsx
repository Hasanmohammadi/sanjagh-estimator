import React from "react";
import type { colorVariant } from "./Design_CommonTypes.gen";

export type TitleVariant =
  | "FristHeader"  // typo preserved from ReScript
  | "SecondHeader"
  | "ThirdHeader"
  | "FourthHeader"
  | "FifthHeader"
  | "SixthHeader"
  | "Body"
  | "Caption";

export type SizeVariant =
  | "FirstTitle"
  | "SecondTitle"
  | "ThirdTitle"
  | "Subtitle"
  | "SmallSubtitle"
  | "Body"
  | "SmallBody"
  | "Caption"
  | "SmallCaption";

export function colorGenerator(color: colorVariant): string {
  switch (color) {
    case "PurpleDark":
      return "text-purpleDesign-dark";
    case "PurpleLight":
      return "text-purpleDesign-light";
    case "PurpleMain":
      return "text-purpleDesign-main";
    case "PurpleVeryLight":
      return "text-purpleDesign-veryLight";
    case "BlackMain":
      return "text-design-black-2";
    case "BlueMain":
      return "text-design-blue-1";
    case "Gray50":
      return "text-design-gray-50";
    case "Gray100":
      return "text-design-gray-100";
    case "Gray150":
      return "text-design-gray-150";
    case "Gray200":
      return "text-design-gray-200";
    case "Gray300":
      return "text-design-gray-300";
    case "Gray400":
      return "text-design-gray-400";
    case "Gray500":
      return "text-design-gray-500";
    case "Gray600":
      return "text-design-gray-600";
    case "GreenMain":
      return "text-design-green";
    case "NewGreenMain":
      return "text-design-newGreen";
    case "RedMain":
      return "text-design-red";
    case "NewRedMain":
      return "text-design-newRed";
    case "YellowMain":
      return "text-design-yellow";
  }
}

function getSizeClassName(sizeVariant: SizeVariant): string {
  switch (sizeVariant) {
    case "FirstTitle":
      return "text-xl/[36px] large:text-[32px]/[48px] font-bold";
    case "SecondTitle":
      return "text-lg/[32px] large:text-2xl/[40px] font-bold";
    case "ThirdTitle":
      return "text-base/[28px] large:text-xl/[36px] font-bold";
    case "Subtitle":
      return "text-sm/[24px] large:text-lg/[32px] font-bold";
    case "SmallSubtitle":
      return "text-xs/[24px] large:text-base/[28px] font-bold";
    case "Body":
      return "text-sm/[22px] large:text-base/[26px]";
    case "SmallBody":
      return "text-xs/[22px] large:text-sm/[22px]";
    case "Caption":
      return "text-[10px]/[18px] large:text-xs/[22px]";
    case "SmallCaption":
      return "text-[8px]/[18px] large:text-[10px]/[18px]";
  }
}

export type DesignTitleProps = {
  titleVariant: TitleVariant;
  sizeVariant: SizeVariant;
  text: string;
  color?: colorVariant;
};

export const DesignTitle: React.FC<DesignTitleProps> = ({
  titleVariant,
  sizeVariant,
  text,
  color = "BlackMain",
}) => {
  const customClassName = getSizeClassName(sizeVariant);
  const className = `${customClassName} ${colorGenerator(color)}`;

  const content = text;

  switch (titleVariant) {
    case "FristHeader":
      return <h1 className={className}>{content}</h1>;
    case "SecondHeader":
      return <h2 className={className}>{content}</h2>;
    case "ThirdHeader":
      return <h3 className={className}>{content}</h3>;
    case "FourthHeader":
      return <h4 className={className}>{content}</h4>;
    case "FifthHeader":
      return <h5 className={className}>{content}</h5>;
    case "SixthHeader":
      return <h6 className={className}>{content}</h6>;
    case "Body":
      return <p className={className}>{content}</p>;
    case "Caption":
      return <span className={className}>{content}</span>;
  }
};

/** Alias for DesignTitle to match ReScript Design_Title.make */
export const make = DesignTitle;

export default DesignTitle;

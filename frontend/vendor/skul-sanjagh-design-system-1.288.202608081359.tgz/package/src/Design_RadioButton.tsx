import { useCallback, useRef, type ChangeEvent } from 'react';

export type RadioButtonSize = 'SmallRadioButton' | 'MediumRadioButton' | 'LargeRadioButton';

const SIZE_CONFIG = {
  SmallRadioButton: {
    control: 'w-4 h-4 min-w-[16px] min-h-[16px]',
    label: 'text-xs',
  },
  MediumRadioButton: {
    control: 'w-[18px] h-[18px] min-w-[18px] min-h-[18px]',
    label: 'text-sm',
  },
  LargeRadioButton: {
    control: 'w-5 h-5 min-w-[20px] min-h-[20px]',
    label: 'text-base',
  },
} as const satisfies Record<
  RadioButtonSize,
  {
    control: string;
    label: string;
  }
>;

const CONTROL_BASE_CLASS =
  'ml-2 rounded-full flex justify-center items-center overflow-visible border border-solid p-[2px]';

export type RadioButtonProps = {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  label: string;
  size?: RadioButtonSize;
  disabled?: boolean;
  id?: string;
  name?: string;
  value?: string;
  className?: string;
};

export function RadioButton({
  checked,
  onCheckedChange,
  label,
  size = 'MediumRadioButton',
  disabled = false,
  id,
  name,
  value,
  className,
}: RadioButtonProps) {
  const fallbackIdRef = useRef<string | undefined>(undefined);
  if (fallbackIdRef.current == null) {
    fallbackIdRef.current = `design-radio-${Math.random().toString(36).slice(2, 9)}`;
  }
  const inputId = id ?? fallbackIdRef.current;
  const { control: controlSizeClass, label: labelSizeClass } = SIZE_CONFIG[size];

  const handleChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>) => {
      onCheckedChange(event.target.checked);
    },
    [onCheckedChange],
  );

  const rootClassName = ['flex items-center', disabled ? 'cursor-not-allowed' : 'cursor-pointer', className]
    .filter(Boolean)
    .join(' ');

  const controlClassName = [
    CONTROL_BASE_CLASS,
    controlSizeClass,
    checked ? (disabled ? 'border-design-gray-300' : 'border-design-black-1') : 'border-design-gray-300',
  ].join(' ');

  const labelClassName = [labelSizeClass, disabled ? 'text-design-gray-400' : '', 'pt-[2px]'].filter(Boolean).join(' ');

  return (
    <label htmlFor={inputId} className={rootClassName}>
      <input
        id={inputId}
        type="radio"
        name={name}
        value={value}
        className="sr-only"
        checked={checked}
        disabled={disabled}
        onChange={handleChange}
      />
      <span aria-hidden className={controlClassName}>
        {checked ? <span className="h-full w-full rounded-full bg-design-black-1" /> : null}
      </span>
      <span className={labelClassName}>{label}</span>
    </label>
  );
}

export default RadioButton;

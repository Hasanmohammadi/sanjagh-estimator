type radionButtonBoxSize = SmallRadioButton | MediumRadioButton | LargeRadioButton

@react.component
let make = (~isSelected, ~onSelect, ~size, ~label, ~disabled=false) => {
  let baseClassName = "ml-2 rounded-full flex justify-center items-center overflow-visible p-[2px]"

  let (sizeClassName, fontSizeClassName) = switch size {
  | SmallRadioButton => {
      let sizeClassName = {
        let className = "w-4 h-4 min-w-[16px] min-h-[16px]"
        className
      }

      let fontSizeClassName = {
        let className = "text-xs"
        className
      }

      (sizeClassName, fontSizeClassName)
    }
  | MediumRadioButton => {
      let sizeClassName = {
        let className = "w-[18px] h-[18px] min-w-[18px] min-h-[18px]"
        className
      }

      let fontSizeClassName = {
        let className = "text-sm"
        className
      }

      (sizeClassName, fontSizeClassName)
    }
  | LargeRadioButton => {
      let sizeClassName = {
        let className = "w-5 h-5 min-w-[20px] min-h-[20px]"
        className
      }

      let fontSizeClassName = {
        let className = "text-base"
        className
      }

      (sizeClassName, fontSizeClassName)
    }
  }

  let selectedClassName = {
    let className = `border border-solid ${disabled
        ? "border-grayDesign-300"
        : "border-blackDesign-main"} `
    `${baseClassName} ${sizeClassName} ${className}`
  }

  let unselectedClassName = {
    let className = "border border-solid border-grayDesign-300"
    `${baseClassName} ${sizeClassName} ${className}`
  }

  let handleClick = _ => {
    switch disabled {
    | true => ()
    | false =>
      let newValue = !isSelected
      onSelect(newValue)
    }
  }

  <span className="flex cursor-pointer items-center" onClick={handleClick}>
    <span className={isSelected ? selectedClassName : unselectedClassName}>
      {isSelected ? <div className="w-full h-full rounded-full bg-blackDesign-main" /> : React.null}
    </span>
    <span className={fontSizeClassName ++ `${disabled ? "text-grayDesign-400" : ""} pt-[2px]`}>
      {label->React.string}
    </span>
  </span>
}

open Design_ColorPalette
open Design_CommonTypes
open Design_ColorPalette

type labelSize = ThinLabel | BoldLabel
type colorVariant =
  | WhiteText({bgColor: Design_ColorPalette.t})
  | BlackText({bgColor: Design_ColorPalette.t})
  | ColorText({textColor: Design_ColorPalette.t})

module Label = {
  module Content = {
    @react.component
    let make = (~variant, ~sizeClassName, ~colorVariant: colorVariant) => {
      let (bgColor, textColor, hasBgOpacity) = switch colorVariant {
      | WhiteText({bgColor}) => (bgColor, White, false)
      | BlackText({bgColor}) => (bgColor, Black1, false)
      | ColorText({textColor}) => (textColor, textColor, true)
      }

      let bgColorClassName = Design_ColorPalette.setBackgroundColorClassName(bgColor)
      let textColorClassName = Design_ColorPalette.setTextColorClassName(textColor)

      switch variant {
      | Text(txt) =>
        <div
          className={`flex justify-center items-center ${sizeClassName} ${bgColorClassName} ${hasBgOpacity
              ? "bg-opacity-20"
              : ""}`}>
          <span className={textColorClassName}> {React.string(txt)} </span>
        </div>
      | TextWithIcon({text, icon, iconPosition}) => {
          let module(Icon) = icon
          let iconClassName = `${textColorClassName} text-sm`

          let (containerClassName, iconMarginClassName) = switch iconPosition {
          | RightPositionedIcon => {
              let containerClassName = `flex flex-row-reverse items-center ${hasBgOpacity
                  ? "bg-opacity-20"
                  : ""}`
              let iconMarginClassName = "ml-[1px]"

              (containerClassName, iconMarginClassName)
            }
          | LeftPositionedIcon => {
              let containerClassName = `flex flex-row items-center ${hasBgOpacity
                  ? "bg-opacity-20"
                  : ""}`
              let iconMarginClassName = "mr-[1px]"

              (containerClassName, iconMarginClassName)
            }
          }

          <span className={`${containerClassName} ${sizeClassName} ${bgColorClassName}`}>
            <span className={textColorClassName}> {React.string(text)} </span>
            <Icon className={`${iconMarginClassName} ${iconClassName}`} />
          </span>
        }
      }
    }
  }

  @react.component
  let make = (~size, ~colorVariant: colorVariant, ~variant) => {
    let sizeClassName = switch size {
    | ThinLabel => {
        let className = "text-[10px] font-normal h-4 px-2 rounded-lg"
        className
      }
    | BoldLabel => {
        let className = "text-[10px] font-bold h-5 px-2 rounded-xl"
        className
      }
    }

    <Content variant sizeClassName colorVariant />
  }
}

module DividedLabel = {
  module DividedLabelWithIcon = {
    @react.component
    let make = (
      ~leftContent,
      ~leftClassName,
      ~icon: React.element,
      ~iconWrapperClassName,
      ~gapClassName,
    ) => {
      module Icon = {
        @react.component
        let make = () => icon
      }

      let baseClassName = "flex items-center px-2"
      let iconBaseClassName = {
        let className = "rounded-r-lg"
        `${baseClassName} ${className}`
      }

      let leftBaseClassName = {
        let className = "rounded-l-lg"
        `${baseClassName} ${className}`
      }

      let gapBaseClassName = {
        let className = "w-1 h-4"
        className
      }

      <span className="inline-flex w-fit h-4 text-[9px] text-grayDesign-600  rounded-lg">
        <span className={`${iconBaseClassName} ${iconWrapperClassName}`}>
          <Icon />
        </span>
        <span className={`${gapBaseClassName} ${gapClassName}`} />
        <span className={`${leftBaseClassName} ${leftClassName}`}>
          {React.string(leftContent)}
        </span>
      </span>
    }
  }

  @react.component
  let make = (
    ~leftContent,
    ~leftClassName,
    ~rightContent,
    ~rightClassName,
    ~gapClassName,
    ~parentClassName=?,
  ) => {
    let baseClassName = "flex items-center px-2"
    let rightBaseClassName = {
      let className = "rounded-r-lg"
      `${baseClassName} ${className}`
    }

    let leftBaseClassName = {
      let className = "rounded-l-lg"
      `${baseClassName} ${className}`
    }

    let gapBaseClassName = {
      let className = "w-1 h-4"
      className
    }

    let parentBaseClassName = "inline-flex w-fit h-4 text-[9px] text-grayDesign-600 px-1 rounded-lg"

    <span className={`${parentBaseClassName} ${parentClassName->Option.getWithDefault("")}`}>
      <span className={`${rightBaseClassName} ${rightClassName}`}>
        {React.string(rightContent)}
      </span>
      <span className={`${gapBaseClassName} ${gapClassName}`} />
      <span className={`${leftBaseClassName} ${leftClassName}`}> {React.string(leftContent)} </span>
    </span>
  }
}

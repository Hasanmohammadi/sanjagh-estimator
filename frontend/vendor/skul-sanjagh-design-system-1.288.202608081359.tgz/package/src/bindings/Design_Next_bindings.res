module GetServerSideProps = {
  module Req = {
    type t
    type headers = {cookie: string}
    type req = {headers: headers, url: string}
  }

  module Res = {
    type t

    @send external setHeader: (t, string, string) => unit = "setHeader"
    @send external write: (t, string) => unit = "write"
    @send external end: t => unit = "end"
  }

  // See: https://github.com/zeit/next.js/blob/canary/packages/next/types/index.d.ts
  type context<'props, 'params> = {
    params: 'params,
    query: Js.Dict.t<string>,
    req: Req.req,
    res: Res.t,
  }

  type redirect = {
    destination: string,
    permanent: bool,
  }

  type propsResult<'props> = {props: 'props}

  type redirectResult = {redirect: redirect}

  type notFoundResult = {notFound: bool}

  type getServerSidePropsResult<'props>

  external notFoundResult: notFoundResult => getServerSidePropsResult<'a> = "%identity"

  external redirectResult: redirectResult => getServerSidePropsResult<'a> = "%identity"

  external propsResult: propsResult<'a> => getServerSidePropsResult<'a> = "%identity"

  type rec result<'props> =
    | Props(propsResult<'props>)
    | Redirect(redirectResult)
    | NotFound(notFoundResult)

  let toGetServerSidePropsResult = x =>
    switch x {
    | Props(p) => propsResult(p)
    | Redirect(r) => redirectResult(r)
    | NotFound(n) => notFoundResult(n)
    }

  // The definition of a getServerSideProps function
  type t<'props, 'params> = context<'props, 'params> => Js.Promise.t<
    getServerSidePropsResult<'props>,
  >
}

module Link = {
  @module("next/link") @react.component
  external make: (
    ~href: string=?,
    ~className: string=?,
    ~_as: string=?,
    ~prefetch: bool=?,
    ~replace: option<bool>=?,
    ~shallow: bool=?,
    ~passHref: option<bool>=?,
    ~target: string=?,
    ~title: string=?,
    ~children: React.element,
    ~\"aria-label": string=?,
  ) => React.element = "default"
}

module Router = {
  module Events = {
    type t

    @send
    external on: (
      t,
      @string
      [
        | #routeChangeStart(string => unit)
        | #routeChangeComplete(string => unit)
        | #routeChangeError(string => unit)
      ],
    ) => unit = "on"

    @send
    external off: (
      t,
      @string
      [
        | #routeChangeStart(string => unit)
        | #routeChangeComplete(string => unit)
        | #routeChangeError(string => unit)
      ],
    ) => unit = "off"
  }

  type t = {
    pathname: string,
    query: Js.Dict.t<string>,
    asPath: string,
    events: Events.t,
    basePath: string,
    isFallback: bool,
    isReady: bool,
    replace: string => unit,
    reload: unit => unit,
    back: unit => unit,
  }

  @module("next/router") external useRouter: unit => t = "useRouter"

  type transitionOptions = {scroll: bool, shallow: bool}

  @send
  external push: (t, ~href: string, ~as_: string=?, ~options: transitionOptions=?, unit) => unit =
    "push"
}

module Head = {
  @module("next/head") @react.component
  external make: (~children: React.element) => React.element = "default"
}

module Error = {
  @module("next/error") @react.component
  external make: (~statusCode: int, ~title: string, ~children: React.element=?) => React.element =
    "default"
}

module GetStaticPaths: {
  type context
  type getStaticPathsResult = {
    paths: array<string>,
    fallback: [#blocking],
  }

  type t = context => Js.Promise.t<getStaticPathsResult>

  let return: t
} = {
  // We don't generate a page on build time
  // and we just want fallback block so we always return this:
  // { paths: [||], fallback: "blocking" }
  type context
  type getStaticPathsResult = {
    paths: array<string>,
    fallback: [#blocking],
  }

  type t = context => Js.Promise.t<getStaticPathsResult>

  let return: t = _ => Js.Promise.resolve({paths: [], fallback: #blocking})
}

module GetStaticProps: {
  type propsResult<'props> = {
    props: 'props,
    revalidate: option<int>,
  }

  type rec redirectResult = {
    redirect: redirectShape,
    revalidate: option<int>,
  }
  and redirectShape = {
    statusCode: int,
    destination: string,
  }

  type result<'p> =
    | Props(propsResult<'p>)
    | Redirect(redirectResult)
    | NotFound({revalidate: option<int>})

  type context<'params> = {params: 'params}

  type getStaticPropsResult<'props>

  type t<'params, 'props> = context<'params> => Js.Promise.t<getStaticPropsResult<'props>>

  let toGetStaticPropsResult: result<'p> => getStaticPropsResult<'p>
} = {
  type propsResult<'props> = {
    props: 'props,
    revalidate: option<int>,
  }

  type rec redirectResult = {
    redirect: redirectShape,
    revalidate: option<int>,
  }
  and redirectShape = {
    statusCode: int,
    destination: string,
  }

  type notFoundResult = {
    // always should be true
    notFound: bool,
    revalidate: option<int>,
  }

  type getStaticPropsResult<'props>

  external notFoundResult: notFoundResult => getStaticPropsResult<'a> = "%identity"

  external redirectResult: redirectResult => getStaticPropsResult<'a> = "%identity"

  external propsResult: propsResult<'a> => getStaticPropsResult<'a> = "%identity"

  type result<'p> =
    | Props(propsResult<'p>)
    | Redirect(redirectResult)
    | NotFound({revalidate: option<int>})

  type context<'params> = {params: 'params}

  type t<'params, 'props> = context<'params> => Js.Promise.t<getStaticPropsResult<'props>>

  let toGetStaticPropsResult = x =>
    switch x {
    | Props(p) => propsResult(p)
    | Redirect(r) => redirectResult(r)
    | NotFound({revalidate}) => notFoundResult({notFound: true, revalidate})
    }
}

module Config = {
  // based on next.config.js
  type serverRuntimeConfig = {
    apiUrl: string,
    agentHost: string,
    agentPort: string,
    domain: string,
    protocol: string,
  }
  type runtimeConfig = {serverRuntimeConfig: serverRuntimeConfig}

  @module("next/config") external get: unit => runtimeConfig = "default"
}

module Image = {
  type imageLoaderProps = {
    src: string,
    width: int,
    quality: option<int>,
  }

  type onLoadingCompleteProps = {
    naturalHeight: int,
    naturalWidth: int,
  }

  @module("next/dist/client/image-component") @react.component
  external make: (
    ~src: string,
    ~id: string=?,
    ~title: string=?,
    ~width: int=?,
    ~height: int=?,
    ~fill: bool=?,
    ~quality: int=?,
    ~priority: bool=?,
    ~loader: imageLoaderProps => string=?,
    ~sizes: string=?,
    ~placeholder: [#blur | #empty]=?,
    ~blurDataURL: string=?,
    ~style: ReactDOM.Style.t=?,
    ~onLoadingComplete: onLoadingCompleteProps => unit=?,
    ~loading: [#"lazy" | #eager]=?,
    ~unoptimized: bool=?,
    // DomProps
    ~onClick: ReactEvent.Mouse.t => unit=?,
    ~alt: string,
    ~className: string=?,
    ~onError: ReactEvent.Media.t => unit=?,
  ) => React.element = "Image"
}

module Dynamic = {
  @deriving(abstract)
  type options = {
    @optional
    ssr: bool,
    @optional
    loading: unit => React.element,
  }

  @module("next/dynamic")
  external dynamic: (unit => Js.Promise.t<'a>, options) => 'a = "default"

  @val external import_: string => Js.Promise.t<'a> = "import"
}

module Script = {
  type innerHtml = {__html: string}
  @module("next/script") @react.component
  external make: (
    ~dangerouslySetInnerHTML: innerHtml,
    ~src: string=?,
    ~strategy: [#beforeInteractive | #afterInteractive | #lazyOnload | #worker],
    ~onLoad: unit => unit=?,
  ) => React.element = "default"
}

module Navigation = {
  type navigationOptions = {scroll: bool, shallow: bool}

  type t = {
    replace: (. string) => unit,
    refresh: (. unit) => unit,
    prefetch: (. string) => unit,
    back: (. unit) => unit,
    forward: (. unit) => unit,
  }

  type searchParamsObj = {get: string => Js.Nullable.t<string>}
  type redirectType = [#replace | #push]

  @module("next/navigation") external useRouter: unit => t = "useRouter"
  @module("next/navigation") external usePathname: unit => string = "usePathname"
  @module("next/navigation") external useParams: unit => Js.Dict.t<string> = "useParams"
  @module("next/navigation") external useSearchParams: unit => searchParamsObj = "useSearchParams"
  @module("next/navigation")
  external redirect: (~path: string, @as("type") ~redirectType: redirectType) => unit = "redirect"
  @module("next/navigation")
  external permanentRedirect: (~path: string, @as("type") ~redirectType: redirectType) => unit =
    "permanentRedirect"
  @module("next/navigation") external notFound: unit => unit = "notFound"

  @send @uncurry
  external push: (t, ~href: string, ~options: navigationOptions=?, unit) => unit = "push"
}

module PagesTypes = {
  type searchParams = Js.Dict.t<string>
  type props<'a> = {params: 'a, searchParams: searchParams}
}

module Fetch = {
  type nextOptions = {revalidate: int}

  type options = {
    cache: string,
    method: string,
    body: Js.Nullable.t<Webapi__Fetch.bodyInit>,
    headers: Webapi.Fetch.HeadersInit.t,
    credentials: string,
    next: nextOptions,
  }

  @val
  external fetch: (Webapi.Fetch.Request.t, options) => promise<Webapi.Fetch.Response.t> = "fetch"

  let makeFetchOptions = (
    ~method: Webapi__Fetch.requestMethod,
    ~body: option<Webapi__Fetch.bodyInit>=?,
    ~cache: Webapi__Fetch.requestCache=Default,
    ~headers: Webapi__Fetch.headersInit,
    ~revalidate: int,
    (),
  ): options => {
    let methodString = switch method {
    | Get => "GET"
    | Post => "POST"
    | Delete => "DELETE"
    | Head => "HEAD"
    | Put => "PUT"
    | _ => ""
    }

    let cacheString = switch cache {
    | ForceCache => "force-cache"
    | NoStore => "no-store"
    | Default => "auto no store"
    | _ => ""
    }

    {
      method: methodString,
      body: Js.Nullable.fromOption(body),
      cache: cacheString,
      headers,
      credentials: "include",
      next: {revalidate: revalidate},
    }
  }

  let fetchWithOptions = (~resource, ~options: options) => {
    let {cache, method, body, headers, credentials, next: {revalidate}} = options
    fetch(resource, {method, body, headers, cache, credentials, next: {revalidate: revalidate}})
  }
}

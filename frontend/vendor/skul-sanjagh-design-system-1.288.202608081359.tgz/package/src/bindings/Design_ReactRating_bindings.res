@module("react-rating") @react.component
external make: (
  ~start: int=?,
  ~stop: int=?,
  ~step: int=?,
  ~fractions: int=?,
  ~initialRating: float,
  ~readonly: bool=?,
  ~emptySymbol: React.element=?,
  ~fullSymbol: React.element=?,
  ~direction: string,
  ~quiet: bool=?,
  ~onChange: int => unit=?,
  ~onClick: int => unit=?,
  ~onHover: int => unit=?,
) => React.element = "default"

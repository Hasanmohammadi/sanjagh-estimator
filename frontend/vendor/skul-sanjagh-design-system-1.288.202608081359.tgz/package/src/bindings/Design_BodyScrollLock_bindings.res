@module("body-scroll-lock")
external disableBodyScroll: Dom.element => unit = "disableBodyScroll"

@module("body-scroll-lock")
external enableBodyScroll: Dom.element => unit = "enableBodyScroll"

@module("body-scroll-lock")
external clearAllBodyScrollLocks: unit => unit = "clearAllBodyScrollLocks"

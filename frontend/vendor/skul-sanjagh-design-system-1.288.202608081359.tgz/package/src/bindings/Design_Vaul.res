module Design_Vaul = {
  module Root = {
    @module("vaul") @scope("Drawer") @react.component
    external make: (
      ~children: React.element=?,
      ~\"open": bool=?,
      ~onOpenChange: bool => unit=?,
      ~className: string=?,
      ~handleOnly: bool=?,
    ) => React.element = "Root"
  }
  module Content = {
    @module("vaul") @scope("Drawer") @react.component
    external make: (~children: React.element=?, ~className: string=?) => React.element = "Content"
  }
  module Overlay = {
    @module("vaul") @scope("Drawer") @react.component
    external make: (~children: React.element=?, ~className: string=?) => React.element = "Overlay"
  }
  module Trigger = {
    @module("vaul") @scope("Drawer") @react.component
    external make: (~children: React.element=?, ~asChild: bool=?) => React.element = "Trigger"
  }
  module Title = {
    @module("vaul") @scope("Drawer") @react.component
    external make: (~children: React.element=?, ~className: string=?) => React.element = "Title"
  }
  module Portal = {
    @module("vaul") @scope("Drawer") @react.component
    external make: (~children: React.element=?, ~className: string=?) => React.element = "Portal"
  }
  module Handle = {
    @module("vaul") @scope("Drawer") @react.component
    external make: unit => React.element = "Handle"
  }
}

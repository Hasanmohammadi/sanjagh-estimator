open Design_Vaul
@react.component
let make = (
  ~isOpen: bool,
  ~onOpenChange: bool => unit,
  ~children: React.element,
  ~className=?,
  ~handleOnly: option<bool>=?,
  ~overlayClassName=?,
  ~handleContainerClassName: option<string>=?,
) => {
  React.useEffect0(() => {
    Some(() => Design_Helper.changeBodyStyle("style", ""))
  })
  let classNameStr = className->Option.getWithDefault("")
  let overlayClassNameStr = overlayClassName->Option.getWithDefault("")
  <Design_Vaul.Root
    \"open"={isOpen} onOpenChange={onOpenChange} className="layout h-screen z-50" ?handleOnly>
    <Design_Vaul.Portal className="grid">
      <Design_Vaul.Overlay
        className={`layout h-screen fixed inset-0 bg-black/40 z-[1000] ${overlayClassNameStr}`}
      />
      <Design_Vaul.Content
        className={`layout bg-zinc-100 flex flex-col rounded-t-[20px] z-[1000] mt-24 fixed bottom-0 left-0 right-0 !h-auto !max-h-[calc(100vh-40px)] outline-none border-none ${classNameStr}`}>
        <div className="topLevelComponent">
          <div className={handleContainerClassName->Option.getWithDefault("")}>
            <Design_Vaul.Handle />
          </div>
          <div className="p-4 bg-white rounded-t-[20px] flex-1 pb-bnb-4">
            <div className="mx-auto w-[68px] h-[3px] flex-shrink-0 rounded-full bg-zinc-300 mb-8" />
            <div className="max-w-md mx-auto">
              <div> {children} </div>
            </div>
          </div>
        </div>
      </Design_Vaul.Content>
    </Design_Vaul.Portal>
  </Design_Vaul.Root>
}

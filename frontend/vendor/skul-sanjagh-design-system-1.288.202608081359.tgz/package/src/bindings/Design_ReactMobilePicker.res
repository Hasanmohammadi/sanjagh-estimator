type wheel = [
  | #natural
  | #off
  | #normal
]
@module("react-mobile-picker") @react.component
external make: (
  ~className: string=?,
  ~value: Js.Dict.t<string>,
  ~onChange: (Js.Dict.t<string> => Js.Dict.t<string>) => unit,
  ~wheelMode: wheel=?,
  ~children: React.element,
) => React.element = "default"

module PickerColumn = {
  @module("react-mobile-picker") @scope("default") @react.component
  external make: (~name: string, ~children: React.element) => React.element = "Column"
}

module PickerItem = {
  type param = {selected: bool}
  @module("react-mobile-picker") @scope("default") @react.component
  external make: (~value: string, ~children: param => React.element) => React.element = "Item"
}

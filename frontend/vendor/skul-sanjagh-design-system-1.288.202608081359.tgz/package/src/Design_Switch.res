type sizeVariant = SM | MD | LG
@react.component
let make = (~size: sizeVariant, ~onClick, ~isActive, ~disabled=false, ~label) => {
  let (containerSizeClassName, circleSizeClassName, toggleStatusClassName) = switch size {
  | SM => ("w-[26px] h-4", "w-3 h-3", "translate-x-3")
  | MD => ("w-[34px] h-5", "w-4 h-4", "translate-x-4")
  | LG => ("w-[42px] h-6", "w-5 h-5", "translate-x-5")
  }

  let fontSizeClassName = switch size {
  | SM => "text-xs "
  | MD => "text-sm "
  | LG => "text-base "
  }

  let toggleStatusBasedClassName = isActive ? "" : toggleStatusClassName

  let handleClick = _ => {
    switch disabled {
    | true => ()
    | false =>
      let newIsActive = !isActive
      onClick(newIsActive)
    }
  }

  <div onClick={handleClick} className="inline-flex cursor-pointer select-none items-center gap-3">
    <span className={fontSizeClassName ++ `${disabled ? "text-grayDesign-400" : ""} pt-[2px]`}>
      {label->React.string}
    </span>
    <div className="relative">
      <input type_="checkbox" id="toggleFour" className="sr-only" />
      <div
        className={`box ${isActive
            ? "bg-blackDesign-main"
            : "bg-grayDesign-300"} bg-blackDesign-main block  rounded-full ${containerSizeClassName}`}
      />
      <div
        className={`absolute flex top-[2px] left-[1px] items-center justify-center rounded-full bg-white transition-transform duration-200 translate-x-0 ${toggleStatusBasedClassName} ${circleSizeClassName}`}
      />
    </div>
  </div>
}

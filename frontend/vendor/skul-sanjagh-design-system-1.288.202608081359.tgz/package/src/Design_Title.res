open Design_CommonTypes

type titleVariant =
  | FristHeader
  | SecondHeader
  | ThirdHeader
  | FourthHeader
  | FifthHeader
  | SixthHeader
  | Body
  | Caption

type sizeVariant =
  | FirstTitle
  | SecondTitle
  | ThirdTitle
  | Subtitle
  | SmallSubtitle
  | Body
  | SmallBody
  | Caption
  | SmallCaption

let colorGenerator = (color: colorVariant) => {
  switch color {
  | PurpleDark => "text-purpleDesign-dark"
  | PurpleLight => "text-purpleDesign-light"
  | PurpleMain => "text-purpleDesign-main"
  | PurpleVeryLight => "text-purpleDesign-veryLight"
  | BlackMain => "text-blackDesign-main"
  | BlueMain => "text-blueDesign-main"
  | Gray50 => "text-grayDesign-50"
  | Gray100 => "text-grayDesign-100"
  | Gray150 => "text-grayDesign-150"
  | Gray200 => "text-grayDesign-200"
  | Gray300 => "text-grayDesign-300"
  | Gray400 => "text-grayDesign-400"
  | Gray500 => "text-grayDesign-500"
  | Gray600 => "text-grayDesign-600"
  | GreenMain => "text-greenDesign-main"
  | NewGreenMain => "text-newGreen-main"
  | RedMain => "text-redDesign-main"
  | NewRedMain => "text-newRedDesign-main"
  | YellowMain => "text-yellowDesign-main"
  }
}

@react.component
let make = (~titleVariant, ~sizeVariant, ~text, ~color=BlackMain) => {
  let content = React.string(text)

  let className = {
    let customeClassName = switch sizeVariant {
    | FirstTitle => "text-xl/[36px] large:text-[32px]/[48px] font-bold"
    | SecondTitle => "text-lg/[32px] large:text-2xl/[40px] font-bold"
    | ThirdTitle => "text-base/[28px] large:text-xl/[36px] font-bold"
    | Subtitle => "text-sm/[24px] large:text-lg/[32px] font-bold"
    | SmallSubtitle => "text-xs/[24px] large:text-base/[28px] font-bold"
    | Body => "text-sm/[22px] large:text-base/[26px]"
    | SmallBody => "text-xs/[22px] large:text-sm/[22px]"
    | Caption => "text-[10px]/[18px] large:text-xs/[22px]"
    | SmallCaption => "text-[8px]/[18px] large:text-[10px]/[18px]"
    }

    customeClassName ++ " " ++ colorGenerator(color)
  }
  switch titleVariant {
  | FristHeader => <h1 className> {content} </h1>
  | SecondHeader => <h2 className> {content} </h2>
  | ThirdHeader => <h3 className> {content} </h3>
  | FourthHeader => <h4 className> {content} </h4>
  | FifthHeader => <h5 className> {content} </h5>
  | SixthHeader => <h6 className> {content} </h6>
  | Body => <p className> {content} </p>
  | Caption => <span className> {content} </span>
  }
}

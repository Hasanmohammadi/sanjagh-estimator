import React from "react";
import type { shadowVariant } from "./Design_CommonTypes.gen";

export type CardPaddingVariant = "SM" | "MD" | "LG";

function getShadowClassName(shadow: shadowVariant): string {
  switch (shadow) {
    case "NoShadow":
      return "";
    case "High":
      return "shadow-designHigh";
    case "Low":
      return "shadow-designLow";
  }
}

function getPaddingClassName(variant: CardPaddingVariant): string {
  switch (variant) {
    case "SM":
      return "p-3";
    case "MD":
      return "p-4";
    case "LG":
      return "p-5";
  }
}

export type CardProps = {
  variant: CardPaddingVariant;
  shadow: shadowVariant;
  extraClassName?: string;
  children: React.ReactNode;
};

export const Card: React.FC<CardProps> = ({
  variant,
  shadow,
  extraClassName,
  children,
}) => {
  const baseClassName = "rounded-xl";
  const shadowClassName = getShadowClassName(shadow);
  const paddingClassName = getPaddingClassName(variant);

  const internalClassName = `${baseClassName} ${shadowClassName} ${paddingClassName}`;
  const className =
    extraClassName != null ? `${internalClassName} ${extraClassName}` : internalClassName;

  return <div className={className}>{children}</div>;
};

export default { Card };

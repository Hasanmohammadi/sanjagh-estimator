@genType
type iconPosition = RightPositionedIcon | LeftPositionedIcon
@genType
type icon = module(ReactIcons.Icon)
@genType
type contentVariant =
  | Text(string)
  | TextWithIcon({text: string, icon: icon, iconPosition: iconPosition})

@genType
type shadowVariant = NoShadow | Low | High

@genType
type colorVariant =
  | PurpleDark
  | PurpleLight
  | PurpleMain
  | PurpleVeryLight
  | BlackMain
  | BlueMain
  | Gray50
  | Gray100
  | Gray150
  | Gray200
  | Gray300
  | Gray400
  | Gray500
  | Gray600
  | GreenMain
  | NewGreenMain
  | RedMain
  | NewRedMain
  | YellowMain

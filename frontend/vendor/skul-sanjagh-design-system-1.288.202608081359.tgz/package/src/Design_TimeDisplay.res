module TimeDateLabel = {
  @react.component
  let make = (~timestamp) => {
    let {jy, jm, jd} = Jalaali.toJalaali(Js.Date.fromFloat(timestamp))
    let formattedDateString = `${jy->Float.toString}/${jm->Float.toString}/${jd->Float.toString}`

    <span className="flex gap-[2px] items-center text-grayDesign-600">
      <ReactIcons.Hi.HiOutlineClock className="text-sm" />
      // <span> {WindowGlobalObject.Date.currentDayPersianName->React.string} </span>
      <span className="text-[10px] font-bold"> {React.string(formattedDateString)} </span>
    </span>
  }
}

@@directive("'use-client'")

type heightVariant = LGTextField | MDTextField | SMTextField
type backgroundVariant = Filled | Outlined
type inputTypeVariant = Error | Normal

module TextArea = {
  @react.component
  let make = (
    ~heightVariant: heightVariant,
    ~backgroundVariant: backgroundVariant,
    ~inputTypeVariant: inputTypeVariant,
    ~placeholder=?,
    ~onTextChanged: string => unit,
    ~guide: option<React.element>=?,
    ~disabled=false,
    ~value: string,
    ~onFocus: option<unit => unit>=?,
    ~onBlur: option<unit => unit>=?,
  ) => {
    let textFieldHeight = switch heightVariant {
    | LGTextField => {
        let className = "h-[120px]"
        className
      }
    | MDTextField => {
        let className = "h-[100px]"
        className
      }
    | SMTextField => {
        let className = "h-20"
        className
      }
    }

    let textSize = switch heightVariant {
    | LGTextField => "text-sm large:text-base"
    | MDTextField => "text-xs large:text-sm"
    | SMTextField => "text-[10px] large:text-xs"
    }

    let background = switch backgroundVariant {
    | Filled => "bg-blackDesign-main/[.08] focus-within:border-2 focus-within:border-blackDesign-main"
    | Outlined => "bg-white border-black/[.48] border-[1px] focus-within:border-blackDesign-main focus-within:border-[2px]"
    }
    let disabledStyle = switch backgroundVariant {
    | Filled => "bg-blackDesign-main/[.04] text-blackDesign-main/[.24]"
    | Outlined => "bg-white border-black/[.12] border-[1px]"
    }

    let error = switch inputTypeVariant {
    | Error => "!border-newRedDesign-main border-solid border-[1px]"
    | Normal => ""
    }

    let inputContainer = `flex flex-row py-2 ${textFieldHeight} ${disabled
        ? disabledStyle
        : background} ${error} focus-within:border-[#3F9CEE] focus:border-[#3F9CEE] rounded-[4px]`

    let inputClassName = `bg-transparent focus:outline-none mx-3 my-1 w-full text-blackDesign-main/[.87] no-scrollbar ${textSize}`

    let handleFocus = _ => {
      switch onFocus {
      | Some(func) => func()
      | None => ()
      }
    }

    let handleBlur = _ => {
      switch onBlur {
      | Some(func) => func()
      | None => ()
      }
    }
    <>
      <div className={inputContainer}>
        <textarea
          value={value}
          disabled
          className={inputClassName}
          placeholder={placeholder->Option.getWithDefault("")}
          onChange={event => onTextChanged(ReactEvent.Form.currentTarget(event)["value"])}
          onFocus={handleFocus}
          onBlur={handleBlur}
        />
      </div>
      <div
        className={`text-xs mt-1 ${inputTypeVariant === Error
            ? "text-newRedDesign-main"
            : "text-blackDesign-main/[.56]"}`}>
        {guide->Option.getWithDefault(React.null)}
      </div>
    </>
  }
}

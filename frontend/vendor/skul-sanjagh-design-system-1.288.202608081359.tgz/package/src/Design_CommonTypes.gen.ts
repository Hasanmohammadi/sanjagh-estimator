/* TypeScript file generated from Design_CommonTypes.res by genType. */

/* eslint-disable */
/* tslint:disable */

export type iconPosition = 'RightPositionedIcon' | 'LeftPositionedIcon';
export interface IconBaseProps extends React.SVGAttributes<SVGElement> {
  children?: React.ReactNode;
  size?: string | number;
  color?: string;
  title?: string;
}
export type iconComponent = React.FC<IconBaseProps>;
export type iconElement = React.ReactElement;

export type contentVariant =
  | { TAG: 'Text'; value: string }
  | {
      TAG: 'TextWithIcon';
      readonly text: string;
      readonly icon: iconComponent;
      readonly iconPosition: iconPosition;
    };

export type shadowVariant = 'NoShadow' | 'Low' | 'High';

export type colorVariant =
  | 'PurpleDark'
  | 'PurpleLight'
  | 'PurpleMain'
  | 'PurpleVeryLight'
  | 'BlackMain'
  | 'BlueMain'
  | 'Gray50'
  | 'Gray100'
  | 'Gray150'
  | 'Gray200'
  | 'Gray300'
  | 'Gray400'
  | 'Gray500'
  | 'Gray600'
  | 'GreenMain'
  | 'NewGreenMain'
  | 'RedMain'
  | 'NewRedMain'
  | 'YellowMain';

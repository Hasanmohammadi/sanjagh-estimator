type colors = {
  white: string,
  black1: string,
  black2: string,
  red: string,
  green: string,
  yellow: string,
  blue1: string,
  blue2: string,
  lightBlue: string,
  gray50: string,
  gray100: string,
  gray200: string,
  gray300: string,
  gray400: string,
  gray500: string,
  gray600: string,
  newYellow: string,
  newBlue: string,
  newGreen: string,
  newRed: string,
}

let colors = {
  white: "#FFFFFF",
  black1: "#000000",
  black2: "#212121",
  red: "#FF3B30",
  green: "#32C759",
  yellow: "#FFC022",
  blue1: "#3F93F3",
  blue2: "#3E76FF",
  lightBlue: "#DCECFD",
  gray50: "#F4F4F4",
  gray100: "#EEEEEE",
  gray200: "#DDDDDD",
  gray300: "#CCCCCC",
  gray400: "#AEAEAE",
  gray500: "#8F8F8F",
  gray600: "#707070",
  newYellow: "#E59723",
  newBlue: "#36447E",
  newGreen: "#326815",
  newRed: "#B02624",
}

type t =
  | White
  | Black1
  | Black2
  | Red
  | Green
  | Yellow
  | Blue1
  | Blue2
  | LightBlue
  | Gray50
  | Gray100
  | Gray200
  | Gray300
  | Gray400
  | Gray500
  | Gray600
  | NewYellow
  | NewBlue
  | NewGreen
  | NewRed

let setBackgroundColorClassName = (color: t) => {
  let className = switch color {
  | White => "bg-design-white"
  | Black1 => "bg-design-black1"
  | Black2 => "bg-design-black2"
  | Red => "bg-design-red"
  | Green => "bg-design-green"
  | Yellow => "bg-design-yellow"
  | Blue1 => "bg-design-blue1"
  | Blue2 => "bg-design-blue2"
  | LightBlue => "bg-design-lightBlue"
  | Gray50 => "bg-design-gray50"
  | Gray100 => "bg-design-gray100"
  | Gray200 => "bg-design-gray200"
  | Gray300 => "bg-design-gray300"
  | Gray400 => "bg-design-gray400"
  | Gray500 => "bg-design-gray500"
  | Gray600 => "bg-design-gray600"
  | NewYellow => "bg-design-newYellow"
  | NewBlue => "bg-design-newBlue"
  | NewGreen => "bg-design-newGreen"
  | NewRed => "bg-design-newRed"
  }

  className
}

let setTextColorClassName = (color: t) => {
  let className = switch color {
  | White => "text-design-white"
  | Black1 => "text-design-black1"
  | Black2 => "text-design-black2"
  | Red => "text-design-red"
  | Green => "text-design-green"
  | Yellow => "text-design-yellow"
  | Blue1 => "text-design-blue1"
  | Blue2 => "text-design-blue2"
  | LightBlue => "text-design-lightBlue"
  | Gray50 => "text-design-gray50"
  | Gray100 => "text-design-gray100"
  | Gray200 => "text-design-gray200"
  | Gray300 => "text-design-gray300"
  | Gray400 => "text-design-gray400"
  | Gray500 => "text-design-gray500"
  | Gray600 => "text-design-gray600"
  | NewYellow => "text-design-newYellow"
  | NewBlue => "text-design-newBlue"
  | NewGreen => "text-design-newGreen"
  | NewRed => "text-design-newRed"
  }

  className
}

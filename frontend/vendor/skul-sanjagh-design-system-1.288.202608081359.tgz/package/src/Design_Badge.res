type notifCountBadgeVariant =
  XSNotifCountBadge | SMNotifCountBadge | MDNotifCountBadge | LGNotifCountBadge

type simpleCircleBadgeSize = XSSimpleCircleBadge | SMSimpleCircleBadge | MDSimpleCircleBadge

module NotifCount = {
  @react.component
  let make = (~count, ~size, ~colorClassName) => {
    let baseClassName = {
      let className = "flex justify-center items-center rounded-full"
      className
    }

    let sizeClassName = switch size {
    | XSNotifCountBadge => {
        let className = "w-1 h-1 text-[9px]"
        className
      }
    | SMNotifCountBadge => {
        let className = "w-2 h-2 text-[10px]"
        className
      }
    | MDNotifCountBadge => {
        let className = "w-3 h-3 text-[11px]"
        className
      }
    | LGNotifCountBadge => {
        let className = "w-4 h-4 text-xs"
        className
      }
    }

    let className = `${baseClassName} ${sizeClassName} ${colorClassName}`

    <span className> {React.int(count)} </span>
  }
}

module SimpleCircleBadge = {
  @react.component
  let make = (~size, ~colorClassName) => {
    let baseClassName = {
      let className = "inline-block rounded-full"
      className
    }

    let sizeClassName = switch size {
    | XSSimpleCircleBadge => {
        let className = "w-1 h-1"
        className
      }
    | SMSimpleCircleBadge => {
        let className = "w-2 h-2"
        className
      }
    | MDSimpleCircleBadge => {
        let className = "w-3 h-3"
        className
      }
    }

    <span className={`${baseClassName} ${sizeClassName} ${colorClassName}`} />
  }
}

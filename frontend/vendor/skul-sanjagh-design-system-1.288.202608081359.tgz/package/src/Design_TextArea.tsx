'use client';

import { useCallback, useRef, type ChangeEvent, type FocusEvent, type ReactNode } from 'react';

export type TextAreaHeightVariant = 'LGTextField' | 'MDTextField' | 'SMTextField';
export type TextAreaBackgroundVariant = 'Filled' | 'Outlined';
export type TextAreaInputTypeVariant = 'Error' | 'Normal';

const HEIGHT_CONFIG = {
  LGTextField: {
    container: 'h-[120px]',
    text: 'text-sm large:text-base',
  },
  MDTextField: {
    container: 'h-[100px]',
    text: 'text-xs large:text-sm',
  },
  SMTextField: {
    container: 'h-20',
    text: 'text-[10px] large:text-xs',
  },
} as const satisfies Record<
  TextAreaHeightVariant,
  {
    container: string;
    text: string;
  }
>;

const BACKGROUND_CONFIG = {
  Filled: {
    enabled: 'bg-blackDesign-main/[.08] focus-within:border-2 focus-within:border-blackDesign-main',
    disabled: 'bg-blackDesign-main/[.04] text-blackDesign-main/[.24]',
  },
  Outlined: {
    enabled: 'bg-white border-black/[.48] border-[1px] focus-within:border-blackDesign-main focus-within:border-[2px]',
    disabled: 'bg-white border-black/[.12] border-[1px]',
  },
} as const satisfies Record<
  TextAreaBackgroundVariant,
  {
    enabled: string;
    disabled: string;
  }
>;

export type TextAreaProps = {
  heightVariant: TextAreaHeightVariant;
  backgroundVariant: TextAreaBackgroundVariant;
  inputTypeVariant: TextAreaInputTypeVariant;
  value: string;
  onTextChanged: (value: string) => void;
  placeholder?: string;
  guide?: ReactNode;
  disabled?: boolean;
  onFocus?: () => void;
  onBlur?: () => void;
  id?: string;
  className?: string;
};

export function TextArea({
  heightVariant,
  backgroundVariant,
  inputTypeVariant,
  value,
  onTextChanged,
  placeholder = '',
  guide,
  disabled = false,
  onFocus,
  onBlur,
  id,
  className,
}: TextAreaProps) {
  const fallbackIdRef = useRef<string | undefined>(undefined);
  if (fallbackIdRef.current == null) {
    fallbackIdRef.current = `design-textarea-${Math.random().toString(36).slice(2, 9)}`;
  }
  const textareaId = id ?? fallbackIdRef.current;
  const guideId = guide != null ? `${textareaId}-guide` : undefined;

  const { container: heightClassName, text: textSizeClassName } = HEIGHT_CONFIG[heightVariant];
  const backgroundClassName = disabled
    ? BACKGROUND_CONFIG[backgroundVariant].disabled
    : BACKGROUND_CONFIG[backgroundVariant].enabled;

  const containerClassName = [
    'flex flex-row rounded-[4px] py-2',
    heightClassName,
    backgroundClassName,
    inputTypeVariant === 'Error' ? '!border-newRedDesign-main border-solid border-[1px]' : '',
    'focus-within:border-[#3F9CEE] focus:border-[#3F9CEE]',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const textareaClassName = [
    'no-scrollbar mx-3 my-1 w-full bg-transparent text-blackDesign-main/[.87] focus:outline-none',
    textSizeClassName,
  ].join(' ');

  const guideClassName = [
    'mt-1 text-xs',
    inputTypeVariant === 'Error' ? 'text-newRedDesign-main' : 'text-blackDesign-main/[.56]',
  ].join(' ');

  const handleChange = useCallback(
    (event: ChangeEvent<HTMLTextAreaElement>) => {
      onTextChanged(event.target.value);
    },
    [onTextChanged],
  );

  const handleFocus = useCallback(
    (_event: FocusEvent<HTMLTextAreaElement>) => {
      onFocus?.();
    },
    [onFocus],
  );

  const handleBlur = useCallback(
    (_event: FocusEvent<HTMLTextAreaElement>) => {
      onBlur?.();
    },
    [onBlur],
  );

  return (
    <>
      <div className={containerClassName}>
        <textarea
          id={textareaId}
          value={value}
          disabled={disabled}
          placeholder={placeholder}
          className={textareaClassName}
          onChange={handleChange}
          onFocus={handleFocus}
          onBlur={handleBlur}
          aria-invalid={inputTypeVariant === 'Error'}
          aria-describedby={guideId}
        />
      </div>
      {guide != null ? (
        <div id={guideId} className={guideClassName}>
          {guide}
        </div>
      ) : null}
    </>
  );
}

export default TextArea;

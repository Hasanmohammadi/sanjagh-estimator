import React from "react";
import type { contentVariant, iconComponent } from "./Design_CommonTypes.gen";

const RIPPLE_EFFECT =
  "relative overflow-hidden after:content-[''] after:bg-[rgba(0,0,0,0.08)] after:rounded-full after:block after:absolute after:top-0 after:right-0 after:bottom-0 after:left-0 after:scale-x-[0.001] after:scale-y-[0.001] after:opacity-0 after:transition-all after:duration-700 after:ease-out active:after:scale-x-[1.2] active:after:scale-y-[1.2] active:after:opacity-100 active:after:duration-0";

export type WidthVariant = "AutoWidthButton" | "FixedWidthButton";
export type HeightVariant = "XSButton" | "SMButton" | "MDButton" | "LGButton" | "XLGButton" | "XXLGButton";
export type ButtonVariant =
  | "PrimarySolidButton"
  | "SecondaryOutlineButton"
  | "SecondaryGrayButton"
  | "TertiaryMainButton"
  | "LinkMainButton";
export type IconButtonVariant =
  | "PrimarySolidIconButton"
  | "SecondaryOutlineIconButton"
  | "SecondaryGrayIconButton"
  | "TertiaryMainIconButton";
export type IconButtonSize = "SmallIconButton" | "LargeIconButton";

function getButtonHorizontalSizing(widthVariant: WidthVariant): string {
  switch (widthVariant) {
    case "AutoWidthButton":
      return "w-fit";
    case "FixedWidthButton":
      return "w-full";
  }
}

function getButtonVerticalSizing(heightVariant: HeightVariant): string {
  switch (heightVariant) {
    case "XSButton":
      return "text-xs font-bold px-3 h-6 rounded-[4px]";
    case "SMButton":
      return "text-sm font-bold px-4 h-8 rounded-lg";
    case "MDButton":
      return "text-sm font-bold px-5 h-10 rounded-lg";
    case "LGButton":
      return "text-base font-bold px-7 h-12 rounded-lg";
    case "XLGButton":
      return "text-lg font-bold px-8 h-14 rounded-xl";
    case "XXLGButton":
      return "text-2xl font-bold h-[72px] rounded-xl";
  }
}

function getButtonVariantBasedClassName(buttonVariant: ButtonVariant, heightVariant: HeightVariant): string {
  switch (buttonVariant) {
    case "PrimarySolidButton":
      return "bg-black text-white outline-none border-none hover:bg-blackDesign-main disabled:bg-design-gray-200";
    case "SecondaryOutlineButton": {
      const base =
        "bg-white text-black border-black border-solid disabled:border-design-gray-200 disabled:text-design-gray-200 hover:bg-design-gray-50 disabled:hover:bg-transparent";
      const border = heightVariant === "XSButton" ? "border" : "border-2";
      return `${base} ${border}`;
    }
    case "SecondaryGrayButton": {
      const base =
        "bg-white text-black border-design-gray-200 border-solid hover:bg-design-gray-100 disabled:text-design-gray-200 disabled:hover:bg-transparent";
      const border = heightVariant === "XSButton" ? "border" : "border-2";
      return `${base} ${border}`;
    }
    case "TertiaryMainButton":
      return "bg-design-gray-100 text-black border-none outline-none hover:bg-design-gray-200 disabled:bg-design-gray-50 disabled:text-design-gray-200";
    case "LinkMainButton":
      return "bg-transparent border-none outline-none text-blueDesign-main hover:text-blueDesign-dark disabled:text-design-gray-200";
  }
}

function getErrorClassName(buttonVariant: ButtonVariant): string {
  switch (buttonVariant) {
    case "PrimarySolidButton":
      return "bg-newRedDesign-light hover:bg-newRedDesign-main";
    case "SecondaryOutlineButton":
      return "text-newRedDesign-light border-newRedDesign-light hover:bg-[#FDDCDC]";
    case "SecondaryGrayButton":
      return "text-newRedDesign-light";
    case "TertiaryMainButton":
      return "text-newRedDesign-light bg-[#FDDCDC] hover:bg-[#FFD4D4]";
    case "LinkMainButton":
      return "text-newRedDesign-light hover:text-newRedDesign-main";
  }
}

function getButtonContent(content: contentVariant) {
  switch (content.TAG) {
    case "Text":
      return content.value;

    case "TextWithIcon": {
      const { text, icon, iconPosition: pos } = content;

      const Icon = icon as React.ElementType;
      const flexClassName =
        pos === "RightPositionedIcon"
          ? "flex flex-row-reverse justify-center items-center"
          : "flex flex-row justify-center items-center";
      const iconMarginClassName = pos === "RightPositionedIcon" ? "ml-2" : "mr-2";
      return (
        <div className={flexClassName}>
          <span>{text}</span>

          <Icon className={`${iconMarginClassName}`} />
        </div>
      );
    }
  }
}

export type ButtonProps = {
  contentVariant: contentVariant;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  widthVariant: WidthVariant;
  heightVariant: HeightVariant;
  buttonVariant: ButtonVariant;
  disabled?: boolean;
  extraClassName?: string;
  containError?: boolean;
};

export const Button: React.FC<ButtonProps> = ({
  contentVariant,
  onClick,
  widthVariant,
  heightVariant,
  buttonVariant,
  disabled = false,
  extraClassName = "",
  containError = false,
}) => {
  const buttonHorizontalSizing = getButtonHorizontalSizing(widthVariant);
  const buttonVerticalSizing = getButtonVerticalSizing(heightVariant);
  const buttonVariantBasedClassName = getButtonVariantBasedClassName(buttonVariant, heightVariant);
  const errorClassName = getErrorClassName(buttonVariant);

  const buttonClassName = [
    buttonHorizontalSizing,
    buttonVerticalSizing,
    buttonVariantBasedClassName,
    extraClassName,
    RIPPLE_EFFECT,
    containError ? errorClassName : "",
  ]
    .filter(Boolean)
    .join(" ");

  const content = getButtonContent(contentVariant);

  if (onClick != null) {
    return (
      <button type="button" onClick={onClick} disabled={disabled} className={buttonClassName}>
        {content}
      </button>
    );
  }
  return (
    <button type="button" disabled={disabled} className={buttonClassName}>
      {content}
    </button>
  );
};

function getIconButtonSizeClassNames(size: IconButtonSize): {
  button: string;
  icon: string;
} {
  switch (size) {
    case "SmallIconButton":
      return { button: "w-10 h-10 rounded-lg", icon: "text-base" };
    case "LargeIconButton":
      return { button: "w-12 h-12 rounded-lg", icon: "text-lg" };
  }
}

function getIconButtonVariantClassName(variant: IconButtonVariant): string {
  switch (variant) {
    case "PrimarySolidIconButton":
      return "bg-black text-white outline-none border-none hover:bg-blackDesign disabled:bg-design-gray-200";
    case "SecondaryOutlineIconButton":
      return "bg-white text-black border-black border-2 border-solid disabled:border-design-gray-200 disabled:text-design-gray-200 hover:bg-design-gray-50 disabled:hover:bg-transparent";
    case "SecondaryGrayIconButton":
      return "bg-white text-black border-design-gray-200 border-2 hover:bg-design-gray-100 disabled:border-design-gray-200 disabled:text-design-gray-200 disabled:hover:bg-transparent";
    case "TertiaryMainIconButton":
      return "bg-design-gray-100 text-black border-none outline-none hover:bg-design-gray-200 disabled:bg-design-gray-50 disabled:text-design-gray-200";
  }
}

function getIconButtonErrorClassName(variant: IconButtonVariant): string {
  switch (variant) {
    case "PrimarySolidIconButton":
      return "bg-newRedDesign-light hover:bg-newRedDesign-main";
    case "SecondaryOutlineIconButton":
      return "text-newRedDesign-light border-newRedDesign-light hover:!bg-[#FDDCDC]";
    case "SecondaryGrayIconButton":
      return "text-newRedDesign-light";
    case "TertiaryMainIconButton":
      return "text-newRedDesign-light !bg-[#FDDCDC] hover:!bg-[#FFD4D4]";
  }
}

export type IconButtonProps = {
  variant: IconButtonVariant;
  icon: iconComponent;
  size: IconButtonSize;
  containError?: boolean;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
};

export const IconButton: React.FC<IconButtonProps> = ({
  variant,
  icon,
  size,
  containError = false,
  disabled = false,
  onClick,
}) => {
  const buttonBaseClassName = "flex justify-center items-center";
  const { button: buttonSizeClassName, icon: iconSizeClassName } = getIconButtonSizeClassNames(size);
  const buttonVariantBasedClassName = getIconButtonVariantClassName(variant);
  const errorClassName = getIconButtonErrorClassName(variant);

  const buttonClassName = [
    buttonBaseClassName,
    buttonSizeClassName,
    buttonVariantBasedClassName,
    RIPPLE_EFFECT,
    containError ? errorClassName : "",
  ]
    .filter(Boolean)
    .join(" ");

  const Icon = icon as React.ElementType;
  return (
    <button type="button" className={buttonClassName} onClick={onClick} disabled={disabled}>
      <Icon className={iconSizeClassName} />
    </button>
  );
};

export default { Button, IconButton };

import React from 'react';
import { Color, setBackgroundColorClassName, setTextColorClassName } from './Design_ColorPalette';

export type LabelSize = 'ThinLabel' | 'BoldLabel';

export type ColorVariant =
  | { type: 'WhiteText'; bgColor: Color }
  | { type: 'BlackText'; bgColor: Color }
  | { type: 'ColorText'; textColor: Color };

type IconComponent = React.ComponentType<{ className?: string }>;

type Variant =
  | { type: 'Text'; text: string }
  | {
      type: 'TextWithIcon';
      text: string;
      icon: IconComponent;
      iconPosition: 'Right' | 'Left';
    };

type ContentProps = {
  variant: Variant;
  sizeClassName: string;
  colorVariant: ColorVariant;
};

const Content: React.FC<ContentProps> = ({ variant, sizeClassName, colorVariant }) => {
  let bgColor: Color;
  let textColor: Color;
  let hasBgOpacity: boolean;

  switch (colorVariant.type) {
    case 'WhiteText':
      bgColor = colorVariant.bgColor;
      textColor = 'White';
      hasBgOpacity = false;
      break;
    case 'BlackText':
      bgColor = colorVariant.bgColor;
      textColor = 'Black1';
      hasBgOpacity = false;
      break;
    case 'ColorText':
      bgColor = colorVariant.textColor;
      textColor = colorVariant.textColor;
      hasBgOpacity = true;
      break;
  }

  const bgColorClassName = setBackgroundColorClassName(bgColor, hasBgOpacity);
  const textColorClassName = setTextColorClassName(textColor);

  if (variant.type === 'Text') {
    return (
      <div className={`flex justify-center items-center ${sizeClassName} ${bgColorClassName}`}>
        <span className={textColorClassName}>{variant.text}</span>
      </div>
    );
  }

  const Icon = variant.icon;

  const [containerClassName, iconMarginClassName] =
    variant.iconPosition === 'Right'
      ? ['flex flex-row-reverse items-center', 'ml-[1px]']
      : ['flex flex-row items-center', 'mr-[1px]'];

  return (
    <span className={`${containerClassName} ${sizeClassName} ${bgColorClassName}`}>
      <span className={textColorClassName}>{variant.text}</span>
      <Icon className={iconMarginClassName} />
    </span>
  );
};

type LabelProps = {
  size: LabelSize;
  colorVariant: ColorVariant;
  variant: Variant;
};

export const Label: React.FC<LabelProps> = ({ size, colorVariant, variant }) => {
  const sizeClassName =
    size === 'ThinLabel' ? 'text-[10px] font-normal h-4 px-2 rounded-lg' : 'text-[10px] font-bold h-5 px-2 rounded-xl';

  return <Content variant={variant} sizeClassName={sizeClassName} colorVariant={colorVariant} />;
};

type DividedLabelWithIconProps = {
  leftContent: string;
  leftClassName: string;
  icon: React.ReactElement;
  iconWrapperClassName: string;
  gapClassName: string;
};

export const DividedLabelWithIcon: React.FC<DividedLabelWithIconProps> = ({
  leftContent,
  leftClassName,
  icon,
  iconWrapperClassName,
  gapClassName,
}) => {
  const baseClassName = 'flex items-center px-2';

  const iconBaseClassName = `${baseClassName} rounded-r-lg`;
  const leftBaseClassName = `${baseClassName} rounded-l-lg`;
  const gapBaseClassName = 'w-1 h-4';

  return (
    <span className="inline-flex w-fit h-4 text-[9px] text-design-gray-600 rounded-lg">
      <span className={`${iconBaseClassName} ${iconWrapperClassName}`}>{icon}</span>
      <span className={`${gapBaseClassName} ${gapClassName}`} />
      <span className={`${leftBaseClassName} ${leftClassName}`}>{leftContent}</span>
    </span>
  );
};

type DividedLabelProps = {
  leftContent: string;
  leftClassName: string;
  rightContent: string;
  rightClassName: string;
  gapClassName: string;
  parentClassName?: string;
};

export const DividedLabel: React.FC<DividedLabelProps> = ({
  leftContent,
  leftClassName,
  rightContent,
  rightClassName,
  gapClassName,
  parentClassName = '',
}) => {
  const baseClassName = 'flex items-center px-2';

  const rightBaseClassName = `${baseClassName} rounded-r-lg`;
  const leftBaseClassName = `${baseClassName} rounded-l-lg`;
  const gapBaseClassName = 'w-1 h-4';

  const parentBaseClassName = 'inline-flex w-fit h-4 text-[9px] text-design-gray-600 px-1 rounded-lg';

  return (
    <span className={`${parentBaseClassName} ${parentClassName}`}>
      <span className={`${rightBaseClassName} ${rightClassName}`}>{rightContent}</span>
      <span className={`${gapBaseClassName} ${gapClassName}`} />
      <span className={`${leftBaseClassName} ${leftClassName}`}>{leftContent}</span>
    </span>
  );
};

import Picker from 'react-mobile-picker';
import { useState } from 'react';
import type { ComboBoxItem } from './Design_ComboBox_DesktopList';

export type Design_ComboBox_MobileListProps = {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean | ((isOpen: boolean) => boolean)) => void;
  setSelectedItem: (item: ComboBoxItem) => void;
  items: ComboBoxItem[];
  pickerTitle: string;
};

export default function Design_ComboBox_MobileList({
  isOpen,
  setIsOpen,
  setSelectedItem,
  items,
  pickerTitle,
}: Design_ComboBox_MobileListProps) {
  const [pickerValue, setPickerValue] = useState({ item: items[0]?.name ?? '' });
  const selectedItem = items.find(item => item.name === pickerValue.item) ?? {
    id: '',
    name: '',
  };

  function handleSelectItem() {
    setSelectedItem(selectedItem);
    setIsOpen(false);
  }

  if (!isOpen) {
    return null;
  }

  return (
    <div
      className="fixed inset-0 z-[1000] flex items-end bg-black/40"
      onClick={event => {
        event.stopPropagation();
        handleSelectItem();
      }}
      role="dialog"
      aria-modal="true"
      aria-label={pickerTitle}
    >
      <div
        className="w-full rounded-t-[20px] bg-white p-4 pb-bnb-4"
        onClick={event => event.stopPropagation()}
      >
        <div className="mx-auto mb-8 h-[3px] w-[68px] rounded-full bg-zinc-300" />
        <div className="flex items-center justify-between pb-5 pt-4">
          <div className="w-full text-center">
            <p className="w-full text-center font-bold">{pickerTitle}</p>
          </div>
          <button
            type="button"
            className="text-xs font-bold text-blueDesign-main"
            onClick={handleSelectItem}
          >
            تایید
          </button>
        </div>
        <Picker className="w-full" value={pickerValue} onChange={setPickerValue} wheelMode="normal">
          <Picker.Column name="item">
            {items.map(item => (
              <Picker.Item key={item.id} value={item.name}>
                {({ selected }: { selected: boolean }) => (
                  <div className={selected ? 'font-bold text-black' : 'text-grayDesign-600'}>
                    {item.name}
                  </div>
                )}
              </Picker.Item>
            ))}
          </Picker.Column>
        </Picker>
      </div>
    </div>
  );
}

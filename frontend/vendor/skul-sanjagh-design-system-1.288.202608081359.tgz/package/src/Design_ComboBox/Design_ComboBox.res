open Design_TextField
open Design_ComboBox_DesktopList
open Design_ComboBox_MobileList

@react.component
let make = (
  ~backgroundVariant: backgroundVariant,
  ~heightVariant: heightVariant,
  ~statusVariant: inputStatusVariant,
  ~value: option<item>,
  ~className=?,
  ~itemsList: array<item>,
  ~listClassName=?,
  ~onItemClick: item => unit,
  ~itemClassName=?,
  ~leftElement: option<React.element>=?,
  ~placeholder: option<string>=?,
  ~pickerTitle,
) => {
  let (isListOpen, setIsListOpen) = React.useState(_ => false)
  let (isMobile, setIsMobile) = React.useState(_ => true)
  let isMounted = Design_Helper.useIsMounted()
  let containerRef = React.useRef(Js.Nullable.null)

  let textFieldHeight = switch heightVariant {
  | XLGTextField => "h-12"
  | LGTextField => "h-10"
  | MDTextField => "h-8"
  | SMTextField => "h-6"
  }

  let textSize = switch heightVariant {
  | XLGTextField
  | LGTextField => "text-base placeholder:text-xs"
  | MDTextField => "text-xs placeholder:text-[8px]"
  | SMTextField => "text-xs placeholder:text-[8px]"
  }

  let background = switch backgroundVariant {
  | Filled => "bg-black/[.04] focus-within:border-2 focus-within:border-black rounded-[4px] hover:bg-black/[.08] "

  | Outlined => "bg-white border-black/[.24] border-[1px]  focus-within:border-black hover:border-black/[.48] hover:border-[1px] "
  }

  let error = switch statusVariant {
  | Error(_) => "!border-redDesign-main border-[1px] !focus-within:border-[2px]"
  | Warning(_) => "!border-yellowDesign-main border-[1px] !focus-within:border-[2px]"
  | Normal => ""
  }
  let fieldExtraClassName = switch className {
  | Some(value) => value
  | None => ""
  }

  let fieldClassName = `flex justify-between w-full rounded-[4px] flex items-center flex-row p-2 cursor-pointer ${textFieldHeight} ${background} ${textSize} ${error} ${fieldExtraClassName} `

  let explanationTextColor = switch statusVariant {
  | Error(_) => "text-[#DE2C28]"
  | Warning(_) => "text-[#f0c78a]"
  | Normal => ""
  }
  let leftElement = switch leftElement {
  | Some(element) => element
  | None => <ReactIcons.Fa.FaAngleDown color="#707070" />
  }

  let text = switch (value, placeholder) {
  | (Some(val), _) => val.name
  | (None, Some(text)) => text
  | _ => ""
  }

  React.useEffect1(() => {
    if isMounted {
      let clientWidth = Webapi__Dom.window->Webapi.Dom.Window.innerWidth

      switch clientWidth > 720 {
      | true => setIsMobile(_ => false)
      | false => setIsMobile(_ => true)
      }
    }
    None
  }, [isMounted])
  React.useEffect0(() => {
    let handler = (event: Webapi__Dom.Event.t) => {
      let target = event->Webapi.Dom.Event.target->Obj.magic
      let container = containerRef.current->Js.Nullable.toOption

      switch container {
      | None => ()
      | Some(el) =>
        if !(el->Webapi__Dom.Element.contains(~child={target})) {
          setIsListOpen(_ => false)
        }
      }
    }

    Webapi__Dom.document->Webapi__Dom.Document.addEventListener("click", handler)

    Some(() => Webapi__Dom.document->Webapi__Dom.Document.removeEventListener("click", handler))
  })

  <div
    className="relative"
    ref={ReactDOM.Ref.domRef(containerRef)}
    onClick={_ => setIsListOpen(isListOpen => !isListOpen)}>
    <div className={fieldClassName}>
      <span> {text->React.string} </span>
      {leftElement}
    </div>
    {switch statusVariant {
    | Error(Some(text))
    | Warning(Some(text)) =>
      <div className={`text-xs mt-1 ${explanationTextColor}`}> {text->React.string} </div>
    | _ => React.null
    }}
    {switch (isListOpen, isMobile) {
    | (false, _) => React.null
    | (true, false) =>
      <Design_ComboBox_DesktopList
        isListOpen setIsListOpen itemClassName itemsList heightVariant listClassName onItemClick
      />
    | (true, true) =>
      <Design_ComboBox_MobileList
        isOpen={isListOpen}
        setIsOpen={setIsListOpen}
        items={itemsList}
        pickerTitle
        setSelectedItem={onItemClick}
      />
    }}
  </div>
}

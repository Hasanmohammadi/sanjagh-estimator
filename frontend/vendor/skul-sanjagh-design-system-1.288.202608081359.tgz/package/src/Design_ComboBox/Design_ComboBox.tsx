'use client';

import { FaAngleDown } from 'react-icons/fa';
import Design_ComboBox_DesktopList, {
  type ComboBoxItem,
} from './Design_ComboBox_DesktopList';
import Design_ComboBox_MobileList from './Design_ComboBox_MobileList';
import {
  type backgroundVariant,
  type heightVariant,
  type inputStatusVariant,
} from '../Design_TextField';
import { type ReactNode, useEffect, useRef, useState } from 'react';

export type { ComboBoxItem } from './Design_ComboBox_DesktopList';

export type Design_ComboBoxProps = {
  backgroundVariant: backgroundVariant;
  heightVariant: heightVariant;
  statusVariant: inputStatusVariant;
  value?: ComboBoxItem | null;
  className?: string;
  itemsList: ComboBoxItem[];
  listClassName?: string;
  onItemClick: (item: ComboBoxItem) => void;
  itemClassName?: string;
  leftElement?: ReactNode;
  placeholder?: string;
  pickerTitle: string;
};

function heightClassName(variant: heightVariant) {
  switch (variant) {
    case 'XLGTextField':
      return 'h-12';
    case 'LGTextField':
      return 'h-10';
    case 'MDTextField':
      return 'h-8';
    case 'SMTextField':
      return 'h-6';
  }
}

function textClassName(variant: heightVariant) {
  return variant === 'XLGTextField' || variant === 'LGTextField'
    ? 'text-base placeholder:text-xs'
    : 'text-xs placeholder:text-[8px]';
}

function backgroundClassName(variant: backgroundVariant) {
  return variant === 'Filled'
    ? 'bg-black/[.04] focus-within:border-2 focus-within:border-black rounded-[4px] hover:bg-black/[.08]'
    : 'bg-white border-black/[.24] border-solid border-[1px] focus-within:border-black hover:border-black/[.48] hover:border-[1px]';
}

function statusClassName(status: inputStatusVariant) {
  switch (status.TAG) {
    case 'Error':
      return '!border-redDesign-main border-[1px] !focus-within:border-[2px]';
    case 'Warning':
      return '!border-yellowDesign-main border-[1px] !focus-within:border-[2px]';
    case 'Normal':
      return '';
  }
}

function explanationColor(status: inputStatusVariant) {
  switch (status.TAG) {
    case 'Error':
      return 'text-[#DE2C28]';
    case 'Warning':
      return 'text-[#f0c78a]';
    case 'Normal':
      return '';
  }
}

/** TypeScript port of `Design_ComboBox.res`. */
export default function Design_ComboBox({
  backgroundVariant,
  heightVariant,
  statusVariant,
  value,
  className,
  itemsList,
  listClassName,
  onItemClick,
  itemClassName,
  leftElement,
  placeholder,
  pickerTitle,
}: Design_ComboBoxProps) {
  const [isListOpen, setIsListOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsMobile(window.innerWidth <= 720);
  }, []);

  useEffect(() => {
    function closeOnOutsideClick(event: globalThis.MouseEvent) {
      if (!containerRef.current?.contains(event.target as Node)) {
        setIsListOpen(false);
      }
    }

    document.addEventListener('click', closeOnOutsideClick);
    return () => document.removeEventListener('click', closeOnOutsideClick);
  }, []);

  const text = value?.name ?? placeholder ?? '';
  const fieldClassName = [
    'flex justify-between w-full rounded-[4px] items-center flex-row p-2 cursor-pointer',
    heightClassName(heightVariant),
    backgroundClassName(backgroundVariant),
    textClassName(heightVariant),
    statusClassName(statusVariant),
    className ?? '',
  ].join(' ');

  return (
    <div
      ref={containerRef}
      className="relative"
      onClick={() => setIsListOpen(open => !open)}
    >
      <div className={fieldClassName}>
        <span>{text}</span>
        {leftElement ?? <FaAngleDown color="#707070" />}
      </div>

      {(statusVariant.TAG === 'Error' || statusVariant.TAG === 'Warning') && statusVariant.value ? (
        <div className={`text-xs mt-1 ${explanationColor(statusVariant)}`}>
          {statusVariant.value}
        </div>
      ) : null}

      {isListOpen && !isMobile ? (
        <Design_ComboBox_DesktopList
          isListOpen={isListOpen}
          setIsListOpen={setIsListOpen}
          itemsList={itemsList}
          itemClassName={itemClassName}
          heightVariant={heightVariant}
          onItemClick={onItemClick}
          listClassName={listClassName}
        />
      ) : null}

      {isListOpen && isMobile ? (
        <Design_ComboBox_MobileList
          isOpen={isListOpen}
          setIsOpen={setIsListOpen}
          setSelectedItem={onItemClick}
          items={itemsList}
          pickerTitle={pickerTitle}
        />
      ) : null}
    </div>
  );
}

type item = {
  name: string,
  id: string,
}

@react.component
let make = (
  ~isListOpen,
  ~itemsList,
  ~itemClassName,
  ~setIsListOpen,
  ~heightVariant: Design_TextField.heightVariant,
  ~onItemClick,
  ~listClassName,
) => {
  let listTopClass = switch heightVariant {
  | XLGTextField => "top-12"
  | LGTextField => "top-10"
  | MDTextField => "top-8"
  | SMTextField => "top-6"
  }

  let handleItemClick = (~e: ReactEvent.Mouse.t, ~item: item) => {
    e->ReactEvent.Mouse.stopPropagation
    onItemClick(item)
    setIsListOpen(_ => false)
  }
  isListOpen
    ? <div
        className={`absolute right-0 left-0 rounded-4 bg-white border border-grayDesign-200 min-h-[100px] ${listTopClass} ${listClassName->Option.getWithDefault(
            "",
          )}`}>
        {itemsList
        ->Array.map(item => {
          <div
            key={item.id}
            onClick={e => handleItemClick(~e, ~item)}
            className={`p-3 hover:bg-grayDesign-50 border-b border-b-grayDesign-100 text-grayDesign-600 cursor-pointer ${itemClassName->Option.getWithDefault(
                "",
              )}`}>
            {item.name->React.string}
          </div>
        })
        ->React.array}
      </div>
    : React.null
}

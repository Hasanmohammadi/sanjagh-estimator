import type { MouseEvent } from 'react';
import type { heightVariant } from '../Design_TextField';

export type ComboBoxItem = {
  id: string;
  name: string;
};

export type Design_ComboBox_DesktopListProps = {
  isListOpen: boolean;
  itemsList: ComboBoxItem[];
  itemClassName?: string;
  setIsListOpen: (isOpen: boolean | ((isOpen: boolean) => boolean)) => void;
  heightVariant: heightVariant;
  onItemClick: (item: ComboBoxItem) => void;
  listClassName?: string;
};

function listTopClassName(variant: heightVariant) {
  switch (variant) {
    case 'XLGTextField':
      return 'top-12';
    case 'LGTextField':
      return 'top-10';
    case 'MDTextField':
      return 'top-8';
    case 'SMTextField':
      return 'top-6';
  }
}

export default function Design_ComboBox_DesktopList({
  isListOpen,
  itemsList,
  itemClassName,
  setIsListOpen,
  heightVariant,
  onItemClick,
  listClassName,
}: Design_ComboBox_DesktopListProps) {
  if (!isListOpen) {
    return null;
  }

  function handleItemClick(event: MouseEvent<HTMLDivElement>, item: ComboBoxItem) {
    event.stopPropagation();
    onItemClick(item);
    setIsListOpen(false);
  }

  return (
    <div
      className={`absolute right-0 left-0 rounded-4 bg-white border border-grayDesign-200 min-h-[100px] ${listTopClassName(heightVariant)} ${listClassName ?? ''}`}
    >
      {itemsList.map(item => (
        <div
          key={item.id}
          onClick={event => handleItemClick(event, item)}
          className={`p-3 hover:bg-grayDesign-50 border-b border-b-grayDesign-100 text-grayDesign-600 cursor-pointer ${itemClassName ?? ''}`}
        >
          {item.name}
        </div>
      ))}
    </div>
  );
}

type tab = {id: string, title: string, onClick: unit => unit}

module Tabs = {
  @react.component
  let make = (~tabList: array<tab>, ~containerClassName, ~selectedTabNumber=?) => {
    let tabBaseClassName = "flex items-center justify-center flex-1 text-xs font-bold text-center transition-colors duration-300 rounded-3xl py-2 cursor-pointer text-grayDesign-400 select-none"

    let tabSelectedClassName = `${tabBaseClassName} bg-black text-white`
    let (selectedTabNumberState, setSelectedTabNumberState) = React.useState(_ => 0)

    <div
      className={`flex shadow-designMain p-[3px] h-11 rounded-3xl bg-white ${containerClassName}`}>
      {tabList
      ->Array.mapWithIndex((index, {id, title, onClick}) => {
        let (handleTabClick, appliedSelectedTabNumber) = switch selectedTabNumber {
        | Some(n) => (onClick, n)
        | None => (
            _ => {
              onClick()
              setSelectedTabNumberState(_ => index)
            },
            selectedTabNumberState,
          )
        }

        <span
          key={title}
          id
          onClick={_ => handleTabClick()}
          className={appliedSelectedTabNumber === index ? tabSelectedClassName : tabBaseClassName}>
          {React.string(title)}
        </span>
      })
      ->React.array}
    </div>
  }
}

module NewTabs = {
  @react.component
  let make = (~tabList: array<tab>, ~containerClassName, ~selectedTabNumber=?) => {
    let tabBaseClassName = "flex flex-auto items-center justify-center text-xs font-bold text-center transition-colors duration-300 rounded-3xl py-2 cursor-pointer select-none px-2"

    let tabSelectedClassName = `${tabBaseClassName} bg-grayDesign-100 text-black`
    let (selectedTabNumberState, setSelectedTabNumberState) = React.useState(_ => 1)

    <div
      className={`flex justify-between shadow-designMain p-1 large:p-2 h-11 large:h-[60px] rounded-3xl large:rounded-full bg-white ${containerClassName}`}>
      {tabList
      ->Array.mapWithIndex((index, {id, title, onClick}) => {
        let (handleTabClick, appliedSelectedTabNumber) = switch selectedTabNumber {
        | Some(n) => (onClick, n)
        | None => (
            _ => {
              onClick()
              setSelectedTabNumberState(_ => index + 1)
            },
            selectedTabNumberState,
          )
        }

        <span
          key={title}
          id
          onClick={_ => handleTabClick()}
          className={appliedSelectedTabNumber === index + 1
            ? tabSelectedClassName
            : tabBaseClassName}>
          {React.string(title)}
        </span>
      })
      ->React.array}
    </div>
  }
}

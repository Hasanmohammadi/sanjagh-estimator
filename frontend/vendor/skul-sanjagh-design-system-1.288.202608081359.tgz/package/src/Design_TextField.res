@@directive("'use-client'")

type heightVariant = XLGTextField | LGTextField | MDTextField | SMTextField
type backgroundVariant = Filled | Outlined
type inputStatusVariant = Error(option<string>) | Normal | Warning(option<string>)
type inputTypeVariant = Text | Number | Tel
type leftContetType = Text(string) | TextWithIcon({text: string, icon: React.element})

@react.component
let make = React.forwardRef((
  ~heightVariant: heightVariant,
  ~backgroundVariant: backgroundVariant,
  ~inputStatusVariant=Normal: inputStatusVariant,
  ~inputTypeVariant=Text: inputTypeVariant,
  ~placeholder: option<string>=?,
  ~onTextChanged: string => unit,
  ~className=?,
  ~rightIcon: option<React.element>=?,
  ~leftContent: option<leftContetType>=?,
  ~disabled=false,
  ~value: string,
  ~maybeInputClassName: option<string>=?,
  ~pattern: option<string>=?,
  ~inputMode: option<string>=?,
  ~isAutoFocus=false,
  ~handleEnterPress: option<unit => unit>=?,
  ~onClick: option<JsxEvent.Mouse.t => unit>=?,
  ref,
) => {
  let textFieldHeight = switch heightVariant {
  | XLGTextField => "h-12"
  | LGTextField => "h-10"
  | MDTextField => "h-8"
  | SMTextField => "h-6"
  }

  let textSize = switch heightVariant {
  | XLGTextField
  | LGTextField => "text-base placeholder:text-xs"
  | MDTextField => "text-xs placeholder:text-[8px]"
  | SMTextField => "text-xs placeholder:text-[8px]"
  }

  let background = switch backgroundVariant {
  | Filled => "bg-black/[.04] focus-within:border-2 focus-within:border-black rounded-[4px] hover:bg-black/[.08] "

  | Outlined => "bg-white border-black/[.24] border-[1px]  focus-within:border-black hover:border-black/[.48] hover:border-[1px] "
  }

  let error = switch inputStatusVariant {
  | Error(_) => "!border-newRedDesign-main border-[1px] !focus-within:border-[2px]"
  | Warning(_) => "!border-yellowDesign-main border-[1px] !focus-within:border-[2px]"
  | Normal => ""
  }
  let outClassName = className->Option.getWithDefault("")
  let inputContainer = `w-full rounded-[4px] flex items-center flex-row py-2 ${textFieldHeight} ${background} ${error} ${outClassName}`

  let rightIconElement = switch rightIcon {
  | Some(icon) => icon
  | None => React.null
  }
  let leftElement = switch leftContent {
  | Some(x) => {
      let result = switch x {
      | Text(text) => <span> {React.string(text)} </span>
      | TextWithIcon({text, icon}) =>
        <span>
          {icon}
          <div> {React.string(text)} </div>
        </span>
      }
      result
    }
  | None => React.null
  }

  let inputClassName = `w-full bg-transparent focus:outline-none mx-2 ${textSize} ${maybeInputClassName->Option.getWithDefault(
      "",
    )}`
  let explanationTextColor = switch inputStatusVariant {
  | Error(_) => "text-newRedDesign-main"
  | Warning(_) => "text-[#f0c78a]"
  | Normal => ""
  }
  let inputType = switch inputTypeVariant {
  | Text => "text"
  | Number => "number"
  | Tel => "tel"
  }

  let handleKeyPress = e => {
    let key = ReactEvent.Keyboard.key(e)
    if key === "Enter" {
      switch handleEnterPress {
      | Some(func) => func()
      | None => ()
      }
    }
  }

  let inputRef = switch ref->Js.Nullable.toOption {
  | Some(ref) => ref
  | None => {
      let defRef = React.useRef(Js.Nullable.null)
      defRef
    }
  }

  React.useEffect1(() => {
    switch inputRef.current->Js.Nullable.toOption {
    | Some(el) if isAutoFocus => el->WindowGlobalObject.Dom.Element.focus
    | _ => ()
    }

    None
  }, [isAutoFocus])

  <>
    <div className={inputContainer}>
      {rightIconElement}
      <input
        ref={ReactDOM.Ref.domRef(inputRef)}
        className={inputClassName}
        type_={inputType}
        inputMode={inputMode->Option.getWithDefault("text")}
        pattern={pattern->Option.getWithDefault("")}
        value={value}
        placeholder={placeholder->Option.getWithDefault("")}
        onChange={event => onTextChanged(ReactEvent.Form.currentTarget(event)["value"])}
        onKeyPress={handleKeyPress}
        onClick={onClick->Option.getWithDefault(_ => ())}
      />
      {leftElement}
    </div>
    {switch inputStatusVariant {
    | Error(Some(text))
    | Warning(Some(text)) =>
      <div className={`text-xs mt-1 ${explanationTextColor}`}> {text->React.string} </div>
    | _ => React.null
    }}
  </>
})

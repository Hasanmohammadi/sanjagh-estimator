'use client'
import { FC } from "react";
import {FaStar} from "react-icons/fa";
import dynamic from "next/dynamic";
export type size = "XSmall" | "Small" | "Large" | "XLarge"
export type starRatingProps = {
    full : boolean , 
    size : size, 
    color: undefined | string
}
export type staticRatingStarsProps = {
    size :size , 
    rate : number , 
    color? : string ,
    onRateChange? : (rate : number) => void
}

export type numericRatingStarsProps = {
    size : size , 
    rate : number, 
    color? : string
}
function getSizeClassName(size : size) {
    switch (size) {
        case "XSmall" : 
            return "text-xs"
        case "Small" : 
            return "text-sm"
        case "Large" : 
            return "text-2xl"
        case "XLarge" : 
            return "text-3xl"
    }
}
export const StarRating : FC<starRatingProps> = ({full ,size , color}) => {
    const colorClassName = color ? color : "text-black"
    const baseClassName = full ? colorClassName : "text-design-gray-200"
    const sizeClassName = getSizeClassName(size)
    const className = `${baseClassName} ${sizeClassName}`

    return <div className={className}>
        <FaStar /> 
    </div>
}


const Rating = dynamic(() => import("react-rating"))
export const StaticRatingStars : FC<staticRatingStarsProps> = ({size , rate , onRateChange , color}) => {
    const isReadOnly = onRateChange ? false : true
    const onChange = (size : number) => {
        if (onRateChange !== undefined) {
            onRateChange(size)
        }
    } 
     
    return (
    <Rating 
        emptySymbol={<StarRating full={false} size={size} color={color} />} 
        fullSymbol={<StarRating full={true} size={size} color={color} />}   
        direction="ltr"
        initialRating={rate}
        readonly={isReadOnly}
        onChange={onChange}
       />)
}

export const NumericRatingStars : FC<numericRatingStarsProps> = ({size , rate , color}) => {
    const roundedRate = Math.round(rate * 10) / 10
    const textColor = color ? color : ""
    return (
    <div className="flex">
        <span className={`font-bold ml-1 ${textColor}`}> {roundedRate}</span>
        <div className="mt-[2px]">
            <StarRating size={size} full={true} color={color} />
        </div>
    </div>)
}
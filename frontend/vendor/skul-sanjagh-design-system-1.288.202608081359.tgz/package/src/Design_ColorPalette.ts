export type Color =
  | 'White'
  | 'Black1'
  | 'Black2'
  | 'Red'
  | 'Green'
  | 'Yellow'
  | 'Blue1'
  | 'Blue2'
  | 'LightBlue'
  | 'Gray50'
  | 'Gray100'
  | 'Gray200'
  | 'Gray300'
  | 'Gray400'
  | 'Gray500'
  | 'Gray600'
  | 'NewYellow'
  | 'NewBlue'
  | 'NewGreen'
  | 'NewRed';

export const colors = {
  white: '#FFFFFF',
  black1: '#000000',
  black2: '#212121',
  red: '#FF3B30',
  green: '#32C759',
  yellow: '#FFC022',
  blue1: '#3F93F3',
  blue2: '#3E76FF',
  lightBlue: '#DCECFD',
  gray50: '#F4F4F4',
  gray100: '#EEEEEE',
  gray200: '#DDDDDD',
  gray300: '#CCCCCC',
  gray400: '#AEAEAE',
  gray500: '#8F8F8F',
  gray600: '#707070',
  newYellow: '#E59723',
  newBlue: '#36447E',
  newGreen: '#326815',
  newRed: '#B02624',
};

export const setBackgroundColorClassName = (color: Color, hasBgOpacity: boolean = false): string => {
  switch (color) {
    case 'White':
      return hasBgOpacity ? 'bg-design-white/20' : 'bg-design-white';

    case 'Black1':
      return hasBgOpacity ? 'bg-design-black-1/20' : 'bg-design-black-1';

    case 'Black2':
      return hasBgOpacity ? 'bg-design-black-2/20' : 'bg-design-black-2';

    case 'Red':
      return hasBgOpacity ? 'bg-design-red/20' : 'bg-design-red';

    case 'Green':
      return hasBgOpacity ? 'bg-design-green/20' : 'bg-design-green';

    case 'Yellow':
      return hasBgOpacity ? 'bg-design-yellow/20' : 'bg-design-yellow';

    case 'Blue1':
      return hasBgOpacity ? 'bg-design-blue-1/20' : 'bg-design-blue-1';

    case 'Blue2':
      return hasBgOpacity ? 'bg-design-blue-2/20' : 'bg-design-blue-2';

    case 'LightBlue':
      return hasBgOpacity ? 'bg-design-lightBlue/20' : 'bg-design-lightBlue';

    case 'Gray50':
      return hasBgOpacity ? 'bg-design-gray-50/20' : 'bg-design-gray-50';

    case 'Gray100':
      return hasBgOpacity ? 'bg-design-gray-100/20' : 'bg-design-gray-100';

    case 'Gray200':
      return hasBgOpacity ? 'bg-design-gray-200/20' : 'bg-design-gray-200';

    case 'Gray300':
      return hasBgOpacity ? 'bg-design-gray-300/20' : 'bg-design-gray-300';

    case 'Gray400':
      return hasBgOpacity ? 'bg-design-gray-400/20' : 'bg-design-gray-400';

    case 'Gray500':
      return hasBgOpacity ? 'bg-design-gray-500/20' : 'bg-design-gray-500';

    case 'Gray600':
      return hasBgOpacity ? 'bg-design-gray-600/20' : 'bg-design-gray-600';

    case 'NewYellow':
      return hasBgOpacity ? 'bg-design-newYellow/20' : 'bg-design-newYellow';

    case 'NewBlue':
      return hasBgOpacity ? 'bg-design-newBlue/20' : 'bg-design-newBlue';

    case 'NewGreen':
      return hasBgOpacity ? 'bg-design-newGreen/20' : 'bg-design-newGreen';

    case 'NewRed':
      return hasBgOpacity ? 'bg-design-newRed/20' : 'bg-design-newRed';
  }
};

export const setTextColorClassName = (color: Color): string => {
  switch (color) {
    case 'White':
      return 'text-design-white';
    case 'Black1':
      return 'text-design-black-1';
    case 'Black2':
      return 'text-design-black-2';
    case 'Red':
      return 'text-design-red';
    case 'Green':
      return 'text-design-green';
    case 'Yellow':
      return 'text-design-yellow';
    case 'Blue1':
      return 'text-design-blue-1';
    case 'Blue2':
      return 'text-design-blue-2';
    case 'LightBlue':
      return 'text-design-lightBlue';
    case 'Gray50':
      return 'text-design-gray-50';
    case 'Gray100':
      return 'text-design-gray-100';
    case 'Gray200':
      return 'text-design-gray-200';
    case 'Gray300':
      return 'text-design-gray-300';
    case 'Gray400':
      return 'text-design-gray-400';
    case 'Gray500':
      return 'text-design-gray-500';
    case 'Gray600':
      return 'text-design-gray-600';
    case 'NewYellow':
      return 'text-design-newYellow';
    case 'NewBlue':
      return 'text-design-newBlue';
    case 'NewGreen':
      return 'text-design-newGreen';
    case 'NewRed':
      return 'text-design-newRed';
  }
};

import React, { ReactElement } from "react";

export type floatingButtonSizeVariant = "SmallFloatingButton" | "LargeFloatingButton"

  type floatingButtonProps = {
    sizeVariant: floatingButtonSizeVariant;
    text: string;
    isVisible: boolean;
    onClick: (e: React.MouseEvent<HTMLButtonElement>) => void;
  };

 export const  FloatingButton : React.FC<floatingButtonProps>=({
    text,
    isVisible,
    sizeVariant, 
    onClick
 }) =>  {
  const mainWrapperBaseClassName = "flex items-center fixed right-2 bottom-20 large:bottom-5 font-bold bg-black border-none text-white z-50 shadow-lg cursor-pointer transition-all duration-300 ease-elastic"
  const plusWrapperBaseClassName = "flex items-center justify-center font-normal bg-[#d9d9d9]/20 bg-opacity-20"

  function getClassName() {
    switch (sizeVariant) {
        case "SmallFloatingButton": 
            return {mainWrapperClassName : mainWrapperBaseClassName + " " + "h-8 rounded-lg p-1 text-sm font-bold" , plusWrapperClassName : plusWrapperBaseClassName + " " + "text-lg font-normal ml-1 w-6 h-6 rounded-[4px]"}
        
        case "LargeFloatingButton" : 
            return {mainWrapperClassName : mainWrapperBaseClassName + " " + "text-2xl font-bold h-[72px] rounded-xl p-2" , plusWrapperClassName : plusWrapperBaseClassName + " " + "text-5xl font-normal ml-3 w-14 h-14 rounded-lg",}
    }
  }

  const {mainWrapperClassName , plusWrapperClassName } = getClassName()


  const visiblityClassName = isVisible ? "" : " hidden"

    return   <button
    aria-label="floating action button"
    className={mainWrapperClassName + visiblityClassName}
    onClick={onClick}>
    {isVisible
      ? <>
          <span className={plusWrapperClassName}> + </span>
          <span> {text} </span>
        </>
      : null}
  </button>
}

export default {FloatingButton}
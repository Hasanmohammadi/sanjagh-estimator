let changeBodyStyle = (atrName, atrValue) => {
  let el = Webapi.Dom.Document.getElementsByTagName(Webapi.Dom.document, "body")
  let body = el->Webapi.Dom.HtmlCollection.toArray->Array.get(0)->Option.getUnsafe
  body->Webapi.Dom.Element.setAttribute(atrName, atrValue)
}

let useIsMounted = () => {
  let (isMounted, setIsMounted) = React.useState(_ => false)

  React.useEffect0(() => {
    setIsMounted(_ => true)

    Some(() => setIsMounted(_ => false))
  })

  isMounted
}

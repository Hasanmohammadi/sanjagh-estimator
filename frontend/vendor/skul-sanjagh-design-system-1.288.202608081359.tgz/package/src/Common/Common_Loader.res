@react.component
let make = () =>
  <div className="w-[70px] flex justify-between items-center">
    <div
      className="w-10 h-10 border-2 border-design-gray-200 border-r-black border-t-black rounded-full animate-spin"
    />
  </div>

module FullPageLoader = {
  @react.component
  let make = (~maybeExtraClassName=?) => {
    let extraClassName = switch maybeExtraClassName {
    | Some(value) => value
    | None => ""
    }
    <div
      className={`fixed inset-0 flex justify-center items-center bg-black/10 cursor-default ${extraClassName}`}>
      <div className="px-3">
        <div
          className="w-10 h-10 border-2 border-design-gray-200 border-r-black border-t-black rounded-full animate-spin"
        />
      </div>
    </div>
  }
}

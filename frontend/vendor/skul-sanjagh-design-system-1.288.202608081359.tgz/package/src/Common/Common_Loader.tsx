type FullPageLoaderProps = {
  extraClassName?: string;
};

function Spinner() {
  return (
    <div className="w-10 h-10 border-2 border-grayDesign-200 border-r-black border-t-black rounded-full animate-spin" />
  );
}

/** Local TS port of design-system `Common_Loader` (package is `.res` only). */
export default function Common_Loader() {
  return (
    <div className="w-[70px] flex justify-between items-center">
      <Spinner />
    </div>
  );
}

export function FullPageLoader({ extraClassName = '' }: FullPageLoaderProps) {
  return (
    <div
      className={`fixed inset-0 flex justify-center items-center bg-black/10 cursor-default ${extraClassName}`}
    >
      <div className="px-3">
        <Spinner />
      </div>
    </div>
  );
}

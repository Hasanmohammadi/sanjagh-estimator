type alertTypeType =
  | Success
  | Warning
  | Error
  | Info
  | Action({actionText: string, onAction: unit => unit})

type alert = {
  id: string,
  message: string,
  alertType: alertTypeType,
}

type contextShape = {
  showToast: (string, ~alertType: alertTypeType=?, unit) => unit,
  removeToast: string => unit,
}

module Constants = {
  let defaultDuration = 3000
}

module AlertContext = {
  let context = React.createContext({
    showToast: (_, ~alertType=Warning, ()) => (),
    removeToast: _ => (),
  })

  module Provider = {
    let provider = React.Context.provider(context)

    @react.component
    let make = (~value, ~children) => React.createElement(provider, {value, children})
  }
}

module InfoIcon = {
  @react.component
  let make = () => {
    <svg
      xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="#3478DD">
      <path
        d="M6 12C9.306 12 12 9.306 12 6C12 2.694 9.306 -2.35517e-07 6 -5.24537e-07C2.694 -8.13556e-07 8.13556e-07 2.694 5.24537e-07 6C2.35517e-07 9.306 2.694 12 6 12ZM6.45 8.4C6.45 8.646 6.246 8.85 6 8.85C5.754 8.85 5.55 8.646 5.55 8.4L5.55 5.4C5.55 5.154 5.754 4.95 6 4.95C6.246 4.95 6.45 5.154 6.45 5.4L6.45 8.4ZM5.448 3.372C5.478 3.294 5.52 3.234 5.574 3.174C5.634 3.12 5.7 3.078 5.772 3.048C5.844 3.018 5.922 3 6 3C6.078 3 6.156 3.018 6.228 3.048C6.3 3.078 6.366 3.12 6.426 3.174C6.48 3.234 6.522 3.294 6.552 3.372C6.582 3.444 6.6 3.522 6.6 3.6C6.6 3.678 6.582 3.756 6.552 3.828C6.522 3.9 6.48 3.966 6.426 4.026C6.366 4.08 6.3 4.122 6.228 4.152C6.084 4.212 5.916 4.212 5.772 4.152C5.7 4.122 5.634 4.08 5.574 4.026C5.52 3.966 5.478 3.9 5.448 3.828C5.418 3.756 5.4 3.678 5.4 3.6C5.4 3.522 5.418 3.444 5.448 3.372Z"
        fill="#3478DD"
      />
    </svg>
  }
}

module ErrorIcon = {
  @react.component
  let make = () => {
    <svg
      xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="#DB0000">
      <path
        d="M11.472 2.988L9.012 0.528C8.724 0.24 8.148 0 7.74 0H4.26C3.852 0 3.276 0.24 2.988 0.528L0.528 2.988C0.24 3.276 0 3.852 0 4.26V7.74C0 8.148 0.24 8.724 0.528 9.012L2.988 11.472C3.276 11.76 3.852 12 4.26 12H7.74C8.148 12 8.724 11.76 9.012 11.472L11.472 9.012C11.76 8.724 12 8.148 12 7.74V4.26C12 3.852 11.76 3.276 11.472 2.988ZM8.418 7.782C8.592 7.956 8.592 8.244 8.418 8.418C8.328 8.508 8.214 8.55 8.1 8.55C7.986 8.55 7.872 8.508 7.782 8.418L6 6.636L4.218 8.418C4.128 8.508 4.014 8.55 3.9 8.55C3.786 8.55 3.672 8.508 3.582 8.418C3.408 8.244 3.408 7.956 3.582 7.782L5.364 6L3.582 4.218C3.408 4.044 3.408 3.756 3.582 3.582C3.756 3.408 4.044 3.408 4.218 3.582L6 5.364L7.782 3.582C7.956 3.408 8.244 3.408 8.418 3.582C8.592 3.756 8.592 4.044 8.418 4.218L6.636 6L8.418 7.782Z"
        fill="#DB0000"
      />
    </svg>
  }
}

module WarningIcon = {
  @react.component
  let make = () => {
    <svg
      xmlns="http://www.w3.org/2000/svg" width="13" height="12" viewBox="0 0 13 12" fill="#ED720C">
      <path
        d="M12.3484 8.50942L8.43602 1.46714C7.91029 0.519613 7.18283 0 6.38202 0C5.5812 0 4.85375 0.519613 4.32802 1.46714L0.415641 8.50942C-0.0795197 9.40805 -0.134538 10.27 0.262813 10.9485C0.660164 11.6271 1.44264 12 2.46964 12H10.2944C11.3214 12 12.1039 11.6271 12.5012 10.9485C12.8986 10.27 12.8436 9.40194 12.3484 8.50942ZM5.92354 4.27916C5.92354 4.02853 6.13138 3.82068 6.38202 3.82068C6.63266 3.82068 6.8405 4.02853 6.8405 4.27916V7.33571C6.8405 7.58635 6.63266 7.79419 6.38202 7.79419C6.13138 7.79419 5.92354 7.58635 5.92354 7.33571V4.27916ZM6.81605 9.60367C6.78548 9.62812 6.75492 9.65257 6.72435 9.67702C6.68767 9.70148 6.651 9.71982 6.61432 9.73204C6.57764 9.75038 6.54096 9.76261 6.49817 9.76872C6.46149 9.77483 6.4187 9.78095 6.38202 9.78095C6.34534 9.78095 6.30255 9.77483 6.25976 9.76872C6.22308 9.76261 6.1864 9.75038 6.14972 9.73204C6.11304 9.71982 6.07636 9.70148 6.03969 9.67702C6.00912 9.65257 5.97856 9.62812 5.94799 9.60367C5.83795 9.48752 5.77071 9.32858 5.77071 9.16964C5.77071 9.0107 5.83795 8.85176 5.94799 8.73561C5.97856 8.71116 6.00912 8.6867 6.03969 8.66225C6.07636 8.6378 6.11304 8.61946 6.14972 8.60723C6.1864 8.58889 6.22308 8.57667 6.25976 8.57056C6.33923 8.55222 6.42481 8.55222 6.49817 8.57056C6.54096 8.57667 6.57764 8.58889 6.61432 8.60723C6.651 8.61946 6.68767 8.6378 6.72435 8.66225C6.75492 8.6867 6.78548 8.71116 6.81605 8.73561C6.92608 8.85176 6.99333 9.0107 6.99333 9.16964C6.99333 9.32858 6.92608 9.48752 6.81605 9.60367Z"
        fill="#ED720C"
      />
    </svg>
  }
}

module SuccessIcon = {
  @react.component
  let make = () => {
    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path
        d="M8.514 0H3.486C1.302 0 0 1.302 0 3.486V8.508C0 10.698 1.302 12 3.486 12H8.508C10.692 12 11.994 10.698 11.994 8.514V3.486C12 1.302 10.698 0 8.514 0ZM8.868 4.62L5.466 8.022C5.382 8.106 5.268 8.154 5.148 8.154C5.028 8.154 4.914 8.106 4.83 8.022L3.132 6.324C2.958 6.15 2.958 5.862 3.132 5.688C3.306 5.514 3.594 5.514 3.768 5.688L5.148 7.068L8.232 3.984C8.406 3.81 8.694 3.81 8.868 3.984C9.042 4.158 9.042 4.44 8.868 4.62Z"
        fill="#198F65"
      />
    </svg>
  }
}

module Renderer = {
  @react.component
  let make = (~maybeAlert, ~removeToast, ~counter) => {
    let (width, setWidth) = React.useState(() => (1000 - counter) / 1000 * 100)
    maybeAlert
    ->Option.map(alert => {
      let handleItemClick = id => removeToast(id)
      let (backgroundColor, borderColor, progressColor) = switch alert.alertType {
      | Warning => ("bg-[#FFF6EA]", "border-[#FDE9D4]", "bg-[#ED720C]")
      | Success => ("bg-[#E8F8F2]", "border-[#D6EFE6]", "bg-[#198F65]")
      | Error => ("bg-[#FFF2F2]", "border-[#FBDADA]", "bg-[#DB0000]")
      | Action(_)
      | Info => ("bg-[#EBF5FF]", "border-[#D9E9FC]", "bg-[#3478DD]")
      }

      let baseClassName = `${backgroundColor} ${borderColor} border-[1px] w-full rounded-2xl mt-2 w-3/4 max-w-[336px] min-h-[56px] flex text-right  gap-2 items-center text-white px-3 h-full`

      let pointerEvent = switch alert.alertType {
      | Warning
      | Success
      | Error
      | Info => "pointer-events-none"
      | Action(_) => ""
      }

      let icon = switch alert.alertType {
      | Warning => <WarningIcon />
      | Success => <SuccessIcon />
      | Error => <ErrorIcon />
      | Info
      | Action(_) =>
        <InfoIcon />
      }
      let percent = (1000 - counter) / 1000 * 100

      let alertElement = switch alert.alertType {
      | Warning
      | Success
      | Error
      | Info =>
        <div
          onClick={_ => handleItemClick(alert.id)}
          key=alert.id
          className={`${baseClassName} pointer-events-[initial]`}>
          {icon}
          <span className=" text-black"> {alert.message->React.string} </span>
        </div>

      | Action({actionText, onAction}) =>
        <div className={` ${baseClassName} !gap-0 justify-center flex-col`}>
          <div className="flex items-center justify-between  flex-1 w-full">
            <div className="flex flex-row justify-between gap-2 items-center">
              {icon}
              <div className=" text-black"> {alert.message->React.string} </div>
            </div>
            <div>
              <Design_Button.Button
                extraClassName="!text-grayDesign-600 !px-0 "
                contentVariant={Text(actionText)}
                buttonVariant={LinkMainButton}
                heightVariant={SMButton}
                disabled=false
                onClick={_ => {
                  handleItemClick(alert.id)
                  onAction()
                }}
                widthVariant={FixedWidthButton}
              />
            </div>
          </div>
          <div className={`${backgroundColor} w-full h-[2px]`}>
            <div className={`animate-toast self-end h-[2px] ${progressColor}`} />
          </div>
        </div>
      }

      <div
        className={`fixed w-full top-10 right-0 z-[9999999999] flex flex-col justify-center items-center ${pointerEvent}`}>
        {alertElement}
      </div>
    })
    ->Option.getWithDefault(React.null)
  }
}

module AlertProvider = {
  @react.component
  let make = (~children) => {
    let (alert, setAlert) = React.useState(() => None)
    let (alertId, setAlertId) = React.useState(() => "")
    let (counter, setCounter) = React.useState(() => Constants.defaultDuration / 1000)
    React.useEffect1(() => {
      if alert->Option.isSome {
        let a = alert->Option.getExn
        let initCounter = switch a.alertType {
        | Success
        | Warning
        | Error
        | Info =>
          Constants.defaultDuration / 1000
        | Action(_) => 5
        }
        setCounter(_ => initCounter)
        let newtimerId = Js.Global.setInterval(() =>
          if counter >= 0 {
            setCounter(c => c - 1)
          }
        , 1000)
        let timeoutId: Js.Global.timeoutId = Js.Global.setTimeout(() => {
          setAlert(_ => None)
          Js.Global.clearInterval(newtimerId)
        }, initCounter * 1000)
        Some(
          () => {
            Js.Global.clearInterval(newtimerId)
            Js.Global.clearTimeout(timeoutId)
          },
        )
      } else {
        None
      }
    }, [alertId])
    let showToast = (message, ~alertType: alertTypeType=Warning, ()) => {
      let id = Design_UUID.make()
      let alert = {id, message, alertType}

      setAlert(_ => Some(alert))
      setAlertId(_ => id)
    }

    let removeToast = _ => setAlert(_ => None)

    <AlertContext.Provider value={showToast, removeToast}>
      <Renderer maybeAlert={alert} removeToast counter />
      children
    </AlertContext.Provider>
  }
}

let use = () => React.useContext(AlertContext.context)

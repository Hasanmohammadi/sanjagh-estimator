'use client';
import type { contentVariant, iconElement } from './Design_CommonTypes.gen';
import type { MouseEventHandler } from 'react';
import { forwardRef, useEffect, useRef } from 'react';

export type heightVariant = 'XLGTextField' | 'LGTextField' | 'MDTextField' | 'SMTextField';
export type backgroundVariant = 'Filled' | 'Outlined';
export type status = 'Normal' | 'Error' | 'Warning';
export type inputStatusVariant = { TAG: status; value?: string };
export type inputTypeVariant = 'text' | 'number' | 'tel';
export type inputModeVariant = 'text' | 'tel' | 'search' | 'email' | 'url' | 'none' | 'numeric' | 'decimal';
export type leftContentVariant = contentVariant;
// export type rightIconVariant = {
//   element: React.ElementType<{ className?: string; size?: number; color?: string }>;
//   className?: string;
//   size?: number;
//   color?: string;
// };

function getHeightClassname(heightVariant: heightVariant) {
  switch (heightVariant) {
    case 'XLGTextField':
      return 'h-12';
    case 'LGTextField':
      return 'h-10';
    case 'MDTextField':
      return 'h-8';
    case 'SMTextField':
      return 'h-6';
  }
}

function getTextClassName(heightVariant: heightVariant) {
  switch (heightVariant) {
    case 'XLGTextField':
      return 'text-base placeholder:text-xs';
    case 'LGTextField':
      return 'text-base placeholder:text-xs';
    case 'MDTextField':
      return 'text-xs placeholder:text-[8px]';
    case 'SMTextField':
      return 'text-xs placeholder:text-[8px]';
  }
}

function getBackgroundClassName(backgroundVariant: backgroundVariant) {
  switch (backgroundVariant) {
    case 'Filled':
      return 'bg-black/[.04] focus-within:border-2 focus-within:border-black rounded-[4px] hover:bg-black/[.08]';
    case 'Outlined':
      return 'bg-white border-black/[.24] border-solid border-[1px]  focus-within:border-black hover:border-black/[.48] hover:border-[1px]';
  }
}

function getInputStatusClassName(inputStatusVariant: inputStatusVariant) {
  switch (inputStatusVariant.TAG) {
    case 'Warning':
      return '!border-yellowDesign-main border-[1px] !focus-within:border-[2px]';
    case 'Error':
      return '!border-newRedDesign-main border-[1px] !focus-within:border-[2px]';
    case 'Normal':
      return '';
  }
}

function getLeftIconElement(leftIconElement: contentVariant | undefined) {
  if (leftIconElement === undefined) {
    return null;
  }

  switch (leftIconElement.TAG) {
    case 'Text': {
      return <span> {leftIconElement.value} </span>;
    }

    case 'TextWithIcon': {
      const { icon } = leftIconElement;
      const Icon = icon as React.ElementType;
      return (
        <span>
          <Icon />
          <div> {leftIconElement.text} </div>
        </span>
      );
    }
  }
}

function getExplanationTextColor(inputStatusVariant: inputStatusVariant) {
  switch (inputStatusVariant.TAG) {
    case 'Error':
      return 'text-newRedDesign-main';
    case 'Warning':
      return 'text-[#f0c78a]';
    case 'Normal':
      return '';
  }
}

function getExplanationText(inputStatusVarinat: inputStatusVariant) {
  if (inputStatusVarinat.value !== undefined) {
    return inputStatusVarinat.value;
  } else {
    return undefined;
  }
}
export type textFieldProps = {
  heightVariant: heightVariant;
  backgroundVariant: backgroundVariant;
  inputStatusVariant?: inputStatusVariant;
  inputTypeVariant?: inputTypeVariant;
  placeholder?: string;
  onTextChanged: (value: string) => void;
  className?: string;
  rightIcon?: iconElement;
  leftContent?: leftContentVariant;
  disabled?: boolean;
  value: string;
  maybeInputClassName?: string;
  pattern?: string;
  inputMode?: inputModeVariant;
  isAutoFocus?: boolean;
  handleEnterPress?: () => void;
  onClick?: MouseEventHandler<HTMLInputElement>;
};
export const TextField = forwardRef<HTMLInputElement, textFieldProps>(function TextField({
  heightVariant,
  backgroundVariant,
  inputStatusVariant = { TAG: 'Normal' },
  inputTypeVariant = 'text',
  value,
  placeholder,
  className,
  maybeInputClassName,
  leftContent,
  rightIcon,
  isAutoFocus = false,
  pattern,
  inputMode = 'text',
  onTextChanged,
  handleEnterPress,
  onClick,
}, ref) {
  const defaultInputRef = useRef<HTMLInputElement>(null);
  const inputRef = ref && typeof ref === 'object' ? ref : defaultInputRef;
  const textFieldHeight = getHeightClassname(heightVariant);
  const textSize = getTextClassName(heightVariant);
  const background = getBackgroundClassName(backgroundVariant);
  const inputStatus = getInputStatusClassName(inputStatusVariant);

  const leftContentElement = getLeftIconElement(leftContent);
  const outClassName = className ? className : '';
  const inputContainerClassName =
    'w-full rounded-[4px] flex items-center flex-row py-2' +
    ' ' +
    textFieldHeight +
    ' ' +
    background +
    ' ' +
    inputStatus +
    ' ' +
    outClassName;
  const inputClassName =
    'w-full bg-transparent border-none focus:outline-none mx-2' +
    ' ' +
    textSize +
    ' ' +
    `${maybeInputClassName ? maybeInputClassName : ''}`;
  const explanationText = getExplanationText(inputStatusVariant);
  const explanationTextColor = getExplanationTextColor(inputStatusVariant);

  function handleKeyPress(e: React.KeyboardEvent<HTMLInputElement>) {
    const key = e.key;

    if (key === 'Enter' && handleEnterPress !== undefined) {
      handleEnterPress();
    }
  }

  useEffect(() => {
    const input = inputRef.current;
    if (input !== null && isAutoFocus) {
      input.focus();
    }
  }, [isAutoFocus]);
  return (
    <>
      <div className={inputContainerClassName}>
        {rightIcon}
        <input
          ref={inputRef}
          className={inputClassName}
          type={inputTypeVariant}
          inputMode={inputMode ?? 'text'}
          pattern={pattern ?? ''}
          value={value}
          placeholder={placeholder ?? ''}
          onChange={event => onTextChanged(event.target.value)}
          onKeyPress={handleKeyPress}
          onClick={onClick}
        />
        {leftContentElement}
      </div>
      {explanationText !== undefined ? (
        <div className={`text-xs mt-1 ${explanationTextColor}`}> {explanationText} </div>
      ) : null}
    </>
  );
});

export default TextField;

type overlayMenuButton = {
  text: string,
  onClick: unit => unit,
}

@react.component
let make = (
  ~isMenuOpen,
  ~onMenuClose,
  ~buttons: array<overlayMenuButton>,
  ~closeButtonLabel="بستن",
) => {
  let topButtonClassName = "!rounded-t-xl !rounded-b-none"
  let bottomButtonClassName = "!rounded-b-xl !rounded-t-none"

  switch isMenuOpen {
  | true =>
    <Common_Modals.Modal isOpen={true} onModalClick={_ => onMenuClose()}>
      <div className="absolute bottom-0 px-3 pb-6 w-full select-none">
        <div>
          {buttons
          ->Array.mapWithIndex((index, {text, onClick}) => {
            let isFirstIndex = index === 0
            let isLastIndex = index === buttons->Array.length - 1
            let isSingleItem = buttons->Array.length === 1

            let className = switch isSingleItem {
            | true => ""
            | false =>
              if isLastIndex {
                bottomButtonClassName
              } else if isFirstIndex {
                topButtonClassName
              } else {
                "!rounded-none"
              }
            }

            <Design_Button.Button
              key={text}
              onClick={_ => {
                onClick()
                onMenuClose()
              }}
              widthVariant={FixedWidthButton}
              heightVariant={XLGButton}
              buttonVariant={SecondaryGrayButton}
              contentVariant={Text(text)}
              extraClassName={className ++ " !border-[1px] !text-base !font-normal"}
            />
          })
          ->React.array}
        </div>
        <Design_Button.Button
          onClick={_ => onMenuClose()}
          widthVariant={FixedWidthButton}
          heightVariant={XLGButton}
          buttonVariant={PrimarySolidButton}
          contentVariant={Text(closeButtonLabel)}
          extraClassName="mt-2 mb-bnb-[-0.75rem] !text-base !font-normal"
        />
      </div>
    </Common_Modals.Modal>

  | false => React.null
  }
}

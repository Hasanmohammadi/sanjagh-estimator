module BodyScrollLock = Design_BodyScrollLock_bindings

let modalWrapperClassName = "flex flex-col fixed top-0 bottom-0 left-0 right-0 z-[9999999] bg-[rgba(0,0,0,0.5)]"

module Modal = {
  @react.component
  let make = (~children, ~isOpen, ~onModalClick=?) => {
    let overlayNode = React.useRef(Js.Nullable.null)

    React.useEffect1(() => {
      switch isOpen {
      | true =>
        overlayNode.current->Js.Nullable.toOption->Option.forEach(BodyScrollLock.disableBodyScroll)
      | false => BodyScrollLock.clearAllBodyScrollLocks()
      }

      Some(() => BodyScrollLock.clearAllBodyScrollLocks())
    }, [isOpen])

    let handleModalClick = _ =>
      switch onModalClick {
      | Some(fn) => fn()
      | None => ()
      }

    switch isOpen {
    | true =>
      <div
        className={modalWrapperClassName}
        ref={ReactDOM.Ref.domRef(overlayNode)}
        onClick={handleModalClick}>
        children
      </div>

    | false => React.null
    }
  }
}

module ModalWithTransition = {
  @react.component
  let make = (~children, ~isOpen, ~extraClassName: option<string>=?) => {
    let className = switch extraClassName {
    | Some(c) => `${modalWrapperClassName} ${c}`
    | None => modalWrapperClassName
    }

    let overlayNode = React.useRef(Js.Nullable.null)

    React.useEffect1(() => {
      switch isOpen {
      | true =>
        overlayNode.current->Js.Nullable.toOption->Option.forEach(BodyScrollLock.disableBodyScroll)
      | false => BodyScrollLock.clearAllBodyScrollLocks()
      }

      Some(() => BodyScrollLock.clearAllBodyScrollLocks())
    }, [isOpen])

    <div className ref={ReactDOM.Ref.domRef(overlayNode)}> children </div>
  }
}

module OneButtonModal = {
  @react.component
  let make = (
    ~isOpen,
    ~onButtonClick,
    ~buttonClassName=?,
    ~mainContainerClassName=?,
    ~buttonContainerClassName=?,
    ~titleClassName=?,
    ~subtitleClassName=?,
    ~titleText,
    ~subtitleText=?,
    ~buttonText,
  ) => {
    let applicableMainContainerClassName = switch mainContainerClassName {
    | Some(className) => className
    | None => "absolute w-11/12 max-w-md h-fit left-0 right-0 top-0 bottom-0 flex flex-col justify-between items-center rounded-xl p-5 bg-white z-[99999] m-auto cursor-default shadow-center min-h-[176px]"
    }

    let applicableTitleClassName = switch titleClassName {
    | Some(className) => className
    | None => {
        let hasSubtitle = subtitleText->Option.isSome
        `text-base font-bold mt-2 text-center w-4/5 leading-9 cursor-default m-auto mb-${hasSubtitle
            ? "3"
            : "10"}`
      }
    }

    let applicableSubtitleClassName = switch subtitleClassName {
    | Some(className) => className
    | None => "text-sm text-gray-500 text-center m-auto mb-10"
    }

    let applicableButtonContainerClassName = switch buttonContainerClassName {
    | Some(className) => className
    | None => "flex flex-col items-center justify-between w-full"
    }

    switch isOpen {
    | true =>
      <div className={modalWrapperClassName}>
        <div className={applicableMainContainerClassName}>
          <div className="w-full">
            <div className={applicableTitleClassName}> {React.string(titleText)} </div>
            {switch subtitleText {
            | Some(text) if text !== "" =>
              <div className={applicableSubtitleClassName}> {React.string(text)} </div>
            | _ => React.null
            }}
          </div>
          <div className={applicableButtonContainerClassName}>
            <Design_Button.Button
              buttonVariant={PrimarySolidButton}
              contentVariant={Text({buttonText})}
              onClick={onButtonClick}
              heightVariant={MDButton}
              widthVariant={FixedWidthButton}
              extraClassName={buttonClassName->Option.getWithDefault("")}
            />
          </div>
        </div>
      </div>

    | false => React.null
    }
  }
}

module TwoButtonPopup = {
  @react.component
  let make = (
    ~onPrimaryButtonClick,
    ~onSecondaryButtonClick,
    ~primaryButtonClassName=?,
    ~secondaryButtonClassName=?,
    ~mainContainerClassName,
    ~buttonsContainerClassName,
    ~titleClassName,
    ~titleText,
    ~primaryButtonText,
    ~secondaryButtonText,
    ~subtitleText,
    ~subtitleClassName,
  ) =>
    <div className=mainContainerClassName>
      <div className="w-full">
        <span className={titleClassName}> {React.string(titleText)} </span>
        {switch subtitleText {
        | Some(text) if text !== "" =>
          <div className={subtitleClassName->Option.getWithDefault("")}> {React.string(text)} </div>
        | _ => React.null
        }}
      </div>
      <div className=buttonsContainerClassName>
        <Design_Button.Button
          buttonVariant={PrimarySolidButton}
          contentVariant={Text({primaryButtonText})}
          widthVariant={FixedWidthButton}
          heightVariant={MDButton}
          onClick={onPrimaryButtonClick}
          extraClassName={primaryButtonClassName->Option.getWithDefault("")}
        />
        <Design_Button.Button
          buttonVariant={SecondaryGrayButton}
          contentVariant={Text({secondaryButtonText})}
          widthVariant={FixedWidthButton}
          heightVariant={MDButton}
          onClick={onSecondaryButtonClick}
          extraClassName={secondaryButtonClassName->Option.getWithDefault("")}
        />
      </div>
    </div>
}

module ModalWithTwoButtonPopup = {
  @react.component
  let make = (
    ~isOpen,
    ~onPrimaryButtonClick,
    ~onSecondaryButtonClick,
    ~primaryButtonClassName,
    ~secondaryButtonClassName,
    ~mainContainerClassName,
    ~buttonsContainerClassName,
    ~titleClassName,
    ~titleText,
    ~primaryButtonText,
    ~secondaryButtonText,
    ~subtitleText=?,
    ~subtitleClassName=?,
  ) => {
    <Modal isOpen>
      <TwoButtonPopup
        onPrimaryButtonClick
        onSecondaryButtonClick
        primaryButtonClassName
        secondaryButtonClassName
        mainContainerClassName
        buttonsContainerClassName
        titleClassName
        titleText
        primaryButtonText
        secondaryButtonText
        subtitleText
        subtitleClassName
      />
    </Modal>
  }
}

module OneButtonPopup = {
  @react.component
  let make = (
    ~showPopup,
    ~onButtonClick,
    ~mainContainerClassName=?,
    ~buttonContainerClassName=?,
    ~titleClassName=?,
    ~subtitleClassName=?,
    ~titleText,
    ~subtitleText=?,
    ~buttonText,
  ) => {
    let applicableMainContainerClassName = switch mainContainerClassName {
    | Some(className) => className
    | None => "absolute w-4/5 max-w-md h-fit left-0 right-0 top-0 bottom-0 flex flex-col justify-between items-center rounded-md p-3 xsm:p-6 bg-gray-100 z-[99999] m-auto cursor-default shadow-center"
    }

    let applicableTitleClassName = switch titleClassName {
    | Some(className) => className
    | None => {
        let hasSubtitle = subtitleText->Option.isSome
        `text-lg text-center w-4/5 leading-9 cursor-default m-auto mb-${hasSubtitle ? "3" : "10"}`
      }
    }

    let applicableSubtitleClassName = switch subtitleClassName {
    | Some(className) => className
    | None => "text-base text-gray-500 text-center m-auto mb-10"
    }

    let applicableButtonContainerClassName = switch buttonContainerClassName {
    | Some(className) => className
    | None => "flex flex-col items-center justify-between w-full"
    }

    switch showPopup {
    | true =>
      <div className={applicableMainContainerClassName}>
        <div>
          <div className={applicableTitleClassName}> {React.string(titleText)} </div>
          {switch subtitleText {
          | Some(text) => <div className={applicableSubtitleClassName}> {React.string(text)} </div>
          | _ => React.null
          }}
        </div>
        <div className={applicableButtonContainerClassName}>
          <Design_Button.Button
            buttonVariant={PrimarySolidButton}
            contentVariant={Text(buttonText)}
            onClick={onButtonClick}
            heightVariant={MDButton}
            widthVariant={FixedWidthButton}
          />
        </div>
      </div>
    | false => React.null
    }
  }
}

module ModalWithCloseButton = {
  @react.component
  let make = (~onRequestClose, ~children, ~isOpen) => {
    let overlayNode = React.useRef(Js.Nullable.null)

    React.useEffect1(() => {
      switch isOpen {
      | true =>
        overlayNode.current->Js.Nullable.toOption->Option.forEach(BodyScrollLock.disableBodyScroll)
      | false => BodyScrollLock.clearAllBodyScrollLocks()
      }

      Some(() => BodyScrollLock.clearAllBodyScrollLocks())
    }, [isOpen])

    switch isOpen {
    | true =>
      <div
        ref={ReactDOM.Ref.domRef(overlayNode)}
        className="flex flex-col fixed top-0 bottom-0 left-0 right-0 z-[9999] bg-black bg-opacity-60">
        <div
          onClick={_ => onRequestClose()}
          className="absolute left-4 top-4 cursor-pointer text-4xl text-gray-400 z-10 opacity-70">
          <ReactIcons.Fa.FaTimes />
        </div>
        children
      </div>
    | false => React.null
    }
  }
}

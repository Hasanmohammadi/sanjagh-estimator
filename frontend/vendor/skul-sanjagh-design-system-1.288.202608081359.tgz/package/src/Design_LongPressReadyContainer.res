@react.component
let make = (~longPressDelayMS, ~onLongPress, ~children, ~onClick=?) => {
  let (waitingForLongPress, setWaitingForLongPress) = React.useState(_ => false)
  let (timeoutId, setTimeoutId) = React.useState(_ => None)

  React.useEffect1(() => {
    switch timeoutId {
    | Some(t) => Js.Global.clearTimeout(t)
    | None => ()
    }

    if waitingForLongPress {
      setTimeoutId(_ => Some(
        Js.Global.setTimeout(
          () => {
            onLongPress()
            setWaitingForLongPress(_ => false)
          },
          longPressDelayMS,
        ),
      ))
    }

    None
  }, [waitingForLongPress])

  <div
    onTouchStart={_ => setWaitingForLongPress(_ => true)}
    onTouchEnd={_ => setWaitingForLongPress(_ => false)}
    onTouchMove={_ => setWaitingForLongPress(_ => false)}
    onContextMenu={e => e->ReactEvent.Mouse.preventDefault}
    ?onClick>
    {children}
  </div>
}

type stepProgressBarStatus = IdleProgressBarStep | ReachedProgressBarStep | DoneProgressBarStep
type stepLevel = [#1 | #2 | #3 | #4 | #5 | #6 | #7 | #8 | #9 | #10]
type stepProgressBar = {
  stepLevel: stepLevel,
  description: string,
}

module Steps = {
  @react.component
  let make = (~stepsList: array<stepProgressBar>, ~currentStep: stepLevel) => {
    module Step = {
      module Line = {
        @react.component
        let make = (~className) => {
          let baseClassName = {
            let className = "h-0 flex-1 border-b-2 border-solid"
            className
          }

          <span className={`${baseClassName} ${className}`} />
        }
      }

      @react.component
      let make = (~status, ~isFirst=false, ~isLast=false, ~description, ~stepNumber) => {
        let spaceClassName = isFirst || isLast ? "flex-1" : "flex-[2]"
        let positionClassName = if isFirst {
          "items-start"
        } else if isLast {
          "items-end"
        } else {
          "items-center"
        }

        let lineClassName = switch status {
        | IdleProgressBarStep => {
            let className = "border-grayDesign-200"
            className
          }
        | ReachedProgressBarStep => {
            let className = "border-blueDesign-main"
            className
          }
        | DoneProgressBarStep => {
            let className = "border-greenDesign-main"
            className
          }
        }

        let stepCircleBaseClassName = {
          let className = "flex justify-center items-center w-5 h-5 rounded-full text-sm"
          className
        }

        let stepStatusBasedClassName = switch status {
        | IdleProgressBarStep => {
            let className = "border border-solid border-gray-200 bg-white text-grayDesign-300"
            className
          }
        | ReachedProgressBarStep => {
            let className = "border-none bg-blueDesign-main text-white"
            className
          }
        | DoneProgressBarStep => {
            let className = "border-none bg-greenDesign-main text-white"
            className
          }
        }

        <span className={`flex flex-col ${spaceClassName} ${positionClassName}`}>
          <span className="flex items-center w-full">
            {isFirst ? React.null : <Line className={lineClassName} />}
            <span className={`${stepCircleBaseClassName} ${stepStatusBasedClassName}`}>
              {switch status {
              | IdleProgressBarStep
              | ReachedProgressBarStep =>
                React.int(stepNumber)
              | DoneProgressBarStep => <ReactIcons.Go.GoCheck />
              }}
            </span>
            {isLast ? React.null : <Line className={lineClassName} />}
          </span>
          <span className="text-[8px] text-[#707070] mt-1"> {React.string(description)} </span>
        </span>
      }
    }

    let stepLevelToInt = step =>
      switch step {
      | #1 => 1
      | #2 => 2
      | #3 => 3
      | #4 => 4
      | #5 => 5
      | #6 => 6
      | #7 => 7
      | #8 => 8
      | #9 => 9
      | #10 => 10
      }

    let getStatus = stepLevel => {
      let stepNumberInt = stepLevelToInt(stepLevel)
      let currentStepInt = stepLevelToInt(currentStep)

      if currentStepInt < stepNumberInt {
        IdleProgressBarStep
      } else if currentStepInt === stepNumberInt {
        ReachedProgressBarStep
      } else {
        DoneProgressBarStep
      }
    }

    <div className="w-full flex justify-between">
      {stepsList
      ->Array.mapWithIndex((index, {stepLevel, description}) => {
        let stepNumber = stepLevelToInt(stepLevel)
        <Step
          key={description ++ index->Int.toString}
          status={getStatus(stepLevel)}
          isFirst={stepLevel === #1}
          isLast={stepNumber === stepsList->Array.size}
          description
          stepNumber
        />
      })
      ->React.array}
    </div>
  }
}

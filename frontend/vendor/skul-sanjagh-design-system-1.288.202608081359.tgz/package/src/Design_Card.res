type cardPaddingVariant = SM | MD | LG
open Design_CommonTypes

module Card = {
  @react.component
  let make = (
    ~variant: cardPaddingVariant,
    ~shadow: shadowVariant,
    ~extraClassName: option<string>=?,
    ~children,
  ) => {
    let baseClassName = "rounded-xl"

    let shadowClassName = switch shadow {
    | NoShadow => ""
    | High => "shadow-designHigh"
    | Low => "shadow-designLow"
    }

    let paddingClassName = switch variant {
    | SM => "p-3"
    | MD => "p-4"
    | LG => "p-5"
    }

    let internalClassName = `${baseClassName} ${shadowClassName} ${paddingClassName}`

    let className = switch extraClassName {
    | Some(c) => `${internalClassName} ${c}`
    | None => internalClassName
    }

    <div className> {children} </div>
  }
}

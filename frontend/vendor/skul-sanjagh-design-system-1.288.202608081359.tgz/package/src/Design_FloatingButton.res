type floatingButtonSizeVariant = SmallFloatingButton | LargeFloatingButton

@react.component
let make = (~sizeVariant, ~onClick, ~text, ~isVisible) => {
  let mainWrapperBaseClassName = "flex items-center fixed right-2 bottom-20 large:bottom-5 font-bold bg-black border-none text-white z-50 shadow-lg cursor-pointer transition-all duration-300 ease-elastic"
  let plusWrappperBaseClassName = "flex items-center justify-center font-normal bg-[#d9d9d9]/20 bg-opacity-20"

  let (mainWrapperClassName, plusWrapperClassName) = switch sizeVariant {
  | SmallFloatingButton => (
      mainWrapperBaseClassName ++ " " ++ "h-8 rounded-lg p-1 text-sm font-bold",
      plusWrappperBaseClassName ++ " " ++ "text-lg font-normal ml-1 w-6 h-6 rounded-[4px]",
    )
  | LargeFloatingButton => (
      mainWrapperBaseClassName ++ " " ++ "text-2xl font-bold h-[72px] rounded-xl p-2",
      plusWrappperBaseClassName ++ " " ++ "text-5xl font-normal ml-3 w-14 h-14 rounded-lg",
    )
  }

  let visiblityClassName = isVisible ? "" : " hidden"

  <button
    ariaLabel="floating action button"
    className={mainWrapperClassName ++ visiblityClassName}
    onClick={onClick}>
    {isVisible
      ? <>
          <span className={plusWrapperClassName}> {React.string("+")} </span>
          <span> {React.string(text)} </span>
        </>
      : React.null}
  </button>
}

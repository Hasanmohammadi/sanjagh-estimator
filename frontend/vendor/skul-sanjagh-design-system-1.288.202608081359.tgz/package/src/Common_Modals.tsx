import { useEffect, useRef, type ReactNode } from 'react';
import { clearAllBodyScrollLocks, disableBodyScroll } from 'body-scroll-lock';
import { Button } from './Design_Button.tsx';

/** Matches design-system `Common_Modals.res` `modalWrapperClassName`. */
const modalWrapperClassName =
  'flex flex-col fixed top-0 bottom-0 left-0 right-0 z-[9999999] bg-[rgba(0,0,0,0.5)]';

export type ModalProps = {
  isOpen: boolean;
  children: ReactNode;
  /** Optional backdrop click handler (`.res` `onModalClick`). */
  onModalClick?: () => void;
  extraClassName?: string;
};

/**
 * Local TS port of design-system `Common_Modals.Modal`.
 * Fixed overlay + body-scroll-lock; backdrop dismiss only if `onModalClick` is set.
 */
export function Modal({
  isOpen,
  children,
  onModalClick,
  extraClassName = '',
}: ModalProps) {
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const node = overlayRef.current;
    if (isOpen && node) {
      disableBodyScroll(node);
    } else {
      clearAllBodyScrollLocks();
    }
    return () => {
      clearAllBodyScrollLocks();
    };
  }, [isOpen]);

  if (!isOpen) {
    return null;
  }

  const className = extraClassName
    ? `${modalWrapperClassName} ${extraClassName}`
    : modalWrapperClassName;

  return (
    <div
      ref={overlayRef}
      className={className}
      data-testid="modal-overlay"
      onClick={onModalClick}
    >
      <div onClick={event => event.stopPropagation()}>{children}</div>
    </div>
  );
}

export type ModalWithTwoButtonPopupProps = {
  isOpen: boolean;
  onPrimaryButtonClick: () => void;
  onSecondaryButtonClick: () => void;
  primaryButtonClassName?: string;
  secondaryButtonClassName?: string;
  primaryButtonDisabled?: boolean;
  mainContainerClassName: string;
  buttonsContainerClassName: string;
  titleClassName: string;
  titleText: string;
  primaryButtonText: string;
  secondaryButtonText: string;
  subtitleText?: string;
  subtitleClassName?: string;
};

/**
 * Local TS port of design-system `Common_Modals.ModalWithTwoButtonPopup`
 * (package modals are `.res` only). Backdrop and Escape do not dismiss —
 * only the buttons.
 */
export function ModalWithTwoButtonPopup({
  isOpen,
  onPrimaryButtonClick,
  onSecondaryButtonClick,
  primaryButtonClassName,
  secondaryButtonClassName,
  primaryButtonDisabled = false,
  mainContainerClassName,
  buttonsContainerClassName,
  titleClassName,
  titleText,
  primaryButtonText,
  secondaryButtonText,
  subtitleText,
  subtitleClassName,
}: ModalWithTwoButtonPopupProps) {
  return (
    <Modal isOpen={isOpen}>
      <div
        className={mainContainerClassName}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-with-two-buttons-title"
      >
        <div className="w-full">
          <span
            id="modal-with-two-buttons-title"
            className={`block w-full text-center ${titleClassName}`}
          >
            {titleText}
          </span>
          {subtitleText ? (
            <div className={subtitleClassName ?? ''}>{subtitleText}</div>
          ) : null}
        </div>
        <div className={buttonsContainerClassName}>
          <Button
            buttonVariant="PrimarySolidButton"
            contentVariant={{ TAG: 'Text', value: primaryButtonText }}
            widthVariant="FixedWidthButton"
            heightVariant="MDButton"
            onClick={onPrimaryButtonClick}
            extraClassName={primaryButtonClassName}
            disabled={primaryButtonDisabled}
          />
          <Button
            buttonVariant="SecondaryGrayButton"
            contentVariant={{ TAG: 'Text', value: secondaryButtonText }}
            widthVariant="FixedWidthButton"
            heightVariant="MDButton"
            onClick={onSecondaryButtonClick}
            extraClassName={secondaryButtonClassName}
          />
        </div>
      </div>
    </Modal>
  );
}

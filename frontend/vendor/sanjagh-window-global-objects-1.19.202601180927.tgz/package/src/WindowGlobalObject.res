type popStateEventState = {idx: int}

type popStateEvent = {
  newURL: string,
  oldURL: string,
  state: Js.Nullable.t<popStateEventState>,
}

%%private(
  @val @scope("window")
  external addEventListener: ([#popstate], popStateEvent => unit) => unit = "addEventListener"
  @val @scope("window")
  external removeEventListener: ([#popstate], popStateEvent => unit) => unit = "removeEventListener"
)

@val @scope(("window", "ReactNativeWebView"))
external postMessage: string => unit = "postMessage"

module Navigator = {
  type coords = {
    latitude: float,
    longitude: float,
    altitude: float,
    accuracy: float,
    altitudeAccuracy: float,
    heading: float,
    speed: float,
  }
  type geoLocationPosition = {
    coords: coords,
    timestamp: float,
  }

  type geoLocationError = {
    code: [#PERMISSION_DENIED | #POSITION_UNAVAILABLE | #TIMEOUT],
    message: string,
  }
  type rec geoLocation = {
    getCurrentPosition: (. geoLocationPosition => unit, geoLocationError => unit) => unit,
  }

  type rec navigator = {geolocation: geoLocation}

  @val @scope("window")
  external navigator: Js.nullable<navigator>= "navigator"
}

let addPopStateEventListener = cb => addEventListener(#popstate, cb)

let removePopStateEventListener = cb => removeEventListener(#popstate, cb)

module History = {
  @val @scope(("window", "history", "state"))
  external browserHistoryIdx: int = "idx"
}

module Date = {
  type t

  type localeString = [#"fa-IR"]
  type yearTypeString = [#numeric]
  type monthTypeString = [#long]
  type weekdayTypeString = [#long]
  type hourTypeString = [#numeric]
  type minuteTypeString = [#numeric]
  type secondTypeString = [#numeric]
  type numberingSystem = [#latn]
  type timeZone = [#"Asia/Tehran"]

  type dateOptions = {
    year: option<yearTypeString>,
    month: option<monthTypeString>,
    weekday: option<weekdayTypeString>,
  }

  type timeOptions = {
    hour: option<hourTypeString>,
    minute: option<minuteTypeString>,
    second: option<secondTypeString>,
    numberingSystem: option<numberingSystem>,
    timeZone: option<timeZone>,
  }

  @new external newDate: unit => t = "Date"
  @send external toLocaleDateString: (t, localeString, dateOptions) => string = "toLocaleDateString"
  @send external toLocaleTimeString: (t, localeString, timeOptions) => string = "toLocaleTimeString"
  @send external getHours: t => int = "getHours"
  @send external getDay: t => int = "getDay"

  type dateConstructorStaticMethods = {now: unit => int}
  external dateConstructor: dateConstructorStaticMethods = "Date"

  let now = newDate()
  let day = getDay(now)
  let hours = getHours(now)

  let makeLocaleDateStringOptions = (~year=?, ~weekday=?, ~month=?, ()) => {year, month, weekday}
  let makeLocaleTimeStringOptions = (
    ~hour=?,
    ~minute=?,
    ~second=?,
    ~numberingSystem=?,
    ~timeZone=?,
    (),
  ) => {hour, minute, second, numberingSystem, timeZone}
  let persianCurrentYear =
    newDate()->toLocaleDateString(#"fa-IR", makeLocaleDateStringOptions(~year=#numeric, ()))
  let currentMonthPersianName =
    newDate()->toLocaleDateString(#"fa-IR", makeLocaleDateStringOptions(~month=#long, ()))
  let currentDayPersianName =
    newDate()->toLocaleDateString(#"fa-IR", makeLocaleDateStringOptions(~weekday=#long, ()))
  let currentHourIranTimeZone =
    newDate()->toLocaleTimeString(
      #"fa-IR",
      makeLocaleTimeStringOptions(
        ~hour={#numeric},
        ~numberingSystem={#latn},
        ~timeZone={#"Asia/Tehran"},
        (),
      ),
    )
}
module Dom = {
  module Element = {
    @send external click: Dom.element => unit = "click"
    @send external focus: Dom.element => unit = "focus"
    @send external setSelectionRange: (Dom.element, int, int) => unit = "setSelectionRange"

    type rect = {top: int}
    @send external getBoundingClientRect: Dom.element => rect = "getBoundingClientRect"
  }
}

module IntersectionObserver = {
  type entry = {isIntersecting: bool}

  type intersectionObserver = {
    disconnect: unit => unit,
    observe: (. Webapi.Dom.Element.t) => unit,
  }

  @new
  external make: (
    ~callback: @uncurry (array<entry> => unit),
    ~options: Webapi.IntersectionObserver.intersectionObserverInit,
  ) => intersectionObserver = "IntersectionObserver"
}

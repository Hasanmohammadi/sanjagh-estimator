const plugin = require('tailwindcss/plugin');
const { screens } = require('tailwindcss/defaultTheme');

module.exports = {
  content: ['./src/**/*.res', './pages_res/**/*.res'],
  theme: {
    screens: {
      xxsm: '300px',
      small: '360px',
      xsm: '390px',
      large: '720px',
      mid: '1024px',
      extraLarge: '1440px',
      ...screens,
    },
    extend: {
      boxShadow: {
        center: '0 0 15px 0 rgb(0 0 0 / 15%)',
        minimal: '0 0 5px rgb(0 0 0 / 25%)',
        designMain: '0 0 10px rgba(0, 0, 0, 0.12)',
        designHigh: '0 0 30px 0 rgba(0, 0, 0, 0.12)',
        designLow: '0 0 10px 0 rgba(0, 0, 0, 0.12)',
      },
      transitionTimingFunction: {
        elastic: 'cubic-bezier(.08,1.09,.32,1.275)',
      },
      fontFamily: {
        vazirmatn: 'var(--font-vazirmatn)',
      },
      keyframes: {
        ripple: {
          '0%': { transform: 'scale(0)' },
          '50%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(0)' },
        },
        spinSlow: {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' },
        },
        countDown: {
          '0%': {
            width: '0%',
          },
          '100%': {
            width: '100%',
          },
        },
      },
      animation: {
        SanjaghLoader: 'ripple 1.8s ease infinite',
        spinSlow: 'spinSlow 4s linear infinite',
        toast: 'countDown 5s forwards',
      },
      colors: {
        design: {
          white: '#FFFFFF',
          black1: '#000000',
          black2: '#212121',
          red: '#FF3B30',
          green: '#32C759',
          yellow: '#FFC022',
          blue1: '#3F93F3',
          blue2: '#3E76FF',
          lightBlue: '#DCECFD',
          gray50: '#F4F4F4',
          gray100: '#EEEEEE',
          gray200: '#DDDDDD',
          gray300: '#CCCCCC',
          gray400: '#AEAEAE',
          gray500: '#8F8F8F',
          gray600: '#707070',
          newYellow: '#E59723',
          newBlue: '#36447E',
          newGreen: '#326815',
          newRed: '#B02624',
        },
        purpleDesign: {
          dark: '#4D4C8D',
          main: '#603D9B',
          light: '#7765DC',
          veryLight: '#BAC3FE',
        },
        blackDesign: {
          main: '#212121',
        },
        blueDesign: {
          main: '#3F93F3',
          dark: '#3E76FF',
          light: '#DCECFD',
        },
        grayDesign: {
          50: '#F2F2F7',
          100: '#E5E5EA',
          200: '#D1D1D6',
          300: '#C7C7CC',
          400: '#AEAEB2',
          500: '#8E8E93',
          600: '#707070',
        },
        greenDesign: {
          main: '#34C759',
        },
        redDesign: {
          main: '#FF3B30',
        },
        yellowDesign: {
          main: '#FFC022',
        },
        purple: {
          Sanjagh: 'rgb(96, 61, 155)',
          SanjaghLight: 'rgb(126, 102, 185)',
        },
        newRedDesign : {
          main : '#B02624'
        }
      },
    },
  },
  plugins: [
    plugin(({ matchUtilities, addBase, theme }) => {
      matchUtilities(
        {
          'animation-delay': value => {
            return {
              'animation-delay': value,
            };
          },
        },
        {
          values: theme('transitionDelay'),
        },
      );

      addBase({
        '.scrollbar-minimal::-webkit-scrollbar': {
          width: '6px',
          height: '6px',
        },

        '.scrollbar-minimal::-webkit-scrollbar-track': {
          borderRadius: '8%',
          backgroundColor: 'rgba(245, 245, 245, 255)',
        },

        '.scrollbar-minimal::-webkit-scrollbar-thumb': {
          backgroundColor: 'rgba(0, 0, 0, 0.08)',
          borderRadius: '100vh',
        },

        '.scrollbar-minimal::-webkit-scrollbar-thumb:hover': {
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
        },

        '.scrollbar-hidden::-webkit-scrollbar': {
          display: 'none',
        },
      });
    }),
  ],
};

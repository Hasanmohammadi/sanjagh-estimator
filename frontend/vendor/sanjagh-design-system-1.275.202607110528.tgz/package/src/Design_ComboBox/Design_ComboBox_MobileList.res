@react.component
let make = (
  ~isOpen,
  ~setIsOpen,
  ~setSelectedItem,
  ~items: array<Design_ComboBox_DesktopList.item>,
  ~pickerTitle,
) => {
  let defaultValue = Js.Dict.fromArray([
    ("item", items[0]->Option.map(v => v.name)->Option.getWithDefault("")),
  ])
  let (pickerValue, setPickerValue) = React.useState(_ => defaultValue)

  let selections = Js.Dict.fromArray([("item", items->Array.map(v => v.name))])

  let handleSelectItem = () => {
    let selectedItemName = pickerValue->Js.Dict.get("item")->Option.getWithDefault("")
    let selectedItem =
      items
      ->Array.getBy(i => i.name === selectedItemName)
      ->Option.getWithDefault({id: "", name: ""})
    setSelectedItem(selectedItem)
    setIsOpen(_ => false)
  }
  <Design_BottomSheetModal
    isOpen onOpenChange={o => setIsOpen(_ => o)} handleOnly={true} overlayClassName="bg-none">
    <div
      onClick={e => e->JsxEvent.Mouse.stopPropagation}
      className="flex items-center justify-between text-center pt-4 pb-5">
      <div className="text-center w-full">
        <p className="font-bold text-center w-full"> {pickerTitle->React.string} </p>
      </div>
      <div onClick={_ => handleSelectItem()}>
        <span className="text-blueDesign-main text-xs font-bold">
          {"تایید"->React.string}
        </span>
      </div>
    </div>
    {<>
      <Design_ReactMobilePicker
        className="w-full" value={pickerValue} onChange={setPickerValue} wheelMode={#normal}>
        {selections
        ->Js.Dict.keys
        ->Array.map(name => {
          switch selections->Js.Dict.get(name) {
          | Some(values) =>
            <Design_ReactMobilePicker.PickerColumn name>
              {values
              ->Array.map(value => {
                <Design_ReactMobilePicker.PickerItem value key={value}>
                  {param => {
                    let className = param.selected ? "font-bold text-black" : "text-grayDesign-600"
                    <div className onClick={e => e->ReactEvent.Mouse.stopPropagation}>
                      {React.string(value)}
                    </div>
                  }}
                </Design_ReactMobilePicker.PickerItem>
              })
              ->React.array}
            </Design_ReactMobilePicker.PickerColumn>
          | None => React.null
          }
        })
        ->React.array}
      </Design_ReactMobilePicker>
    </>}
  </Design_BottomSheetModal>
}
